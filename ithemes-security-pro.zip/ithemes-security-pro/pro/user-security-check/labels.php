<?php

return [
	'title' => __( 'User Security Check', 'it-l10n-ithemes-security-pro' ),
];
