<?php

return [
	'title' => __( 'Dashboard', 'it-l10n-ithemes-security-pro' ),
];
