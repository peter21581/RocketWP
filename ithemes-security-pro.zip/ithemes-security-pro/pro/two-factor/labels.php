<?php

return [
	'title' => __( 'Two-Factor', 'it-l10n-ithemes-security-pro' ),
];
