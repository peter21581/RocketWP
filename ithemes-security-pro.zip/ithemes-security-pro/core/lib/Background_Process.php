<?php

namespace iThemesSecurity\Lib;

abstract class Background_Process extends \Ithemes_Ithemes_Security_ProWP_Background_Process {
	protected $prefix = 'solid-security';
}
