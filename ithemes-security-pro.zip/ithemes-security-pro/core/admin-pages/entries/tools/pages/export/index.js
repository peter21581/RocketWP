import { ExportSlot } from '../../components/slot-fill';

export default function Export() {
	return <ExportSlot />;
}
