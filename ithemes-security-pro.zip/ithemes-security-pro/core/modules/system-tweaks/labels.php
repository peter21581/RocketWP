<?php

return [
	'title' => __( 'System Tweaks', 'it-l10n-ithemes-security-pro' ),
];
