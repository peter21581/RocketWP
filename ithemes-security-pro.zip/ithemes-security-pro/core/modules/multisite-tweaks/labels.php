<?php

return [
	'title' => __( 'Multisite Tweaks', 'it-l10n-ithemes-security-pro' ),
];
