/**
 * External dependencies
 */
import styled from '@emotion/styled';

export const StyledSearchContainer = styled.div`
	padding: 1rem;
`;
