<?php

namespace iThemesSecurity\Exception;

class Unsatisfied_Module_Dependencies_Exception extends \RuntimeException implements Exception {

}
