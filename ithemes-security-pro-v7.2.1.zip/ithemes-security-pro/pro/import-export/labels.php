<?php

return [
	'title' => __( 'Import/Export', 'it-l10n-ithemes-security-pro' ),
];
