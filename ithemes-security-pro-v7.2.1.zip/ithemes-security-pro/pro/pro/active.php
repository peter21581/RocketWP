<?php

require_once( dirname( __FILE__ ) . '/class-itsec-pro-admin.php' );
$admin = new ITSEC_Pro_Admin();
$admin->run();
