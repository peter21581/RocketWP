<?php
/**
 * Main class
 *
 * @author  Yithemes
 * @package YITH Product Size Charts for WooCommerce
 * @version 1.0.0
 */


if ( !defined( 'YITH_WCPSC' ) ) {
    exit;
} // Exit if accessed directly

if ( !class_exists( 'YITH_WCPSC_Premium' ) ) {
    /**
     * YITH Product Size Charts for WooCommerce Premium
     *
     * @since 1.0.0
     */
    class YITH_WCPSC_Premium extends YITH_WCPSC {

        /**
         * Single instance of the class
         *
         * @var YITH_WCPSC_Premium
         * @since 1.0.0
         */
        protected static $_instance;

        /**
         * Constructor
         *
         * @return mixed| YITH_WCPSC_Admin | YITH_WCPSC_Frontend
         * @since 1.0.0
         */
        public function __construct() {
            parent::__construct();

            YITH_WCPSC_Compatibility();

			// register plugin to licence/update system
			add_action( 'wp_loaded', array( $this, 'register_plugin_for_activation' ), 99 );
			add_action( 'admin_init', array( $this, 'register_plugin_for_updates' ) );
        }

		/**
		 * Register plugins for activation tab
		 *
		 * @return void
		 * @since 1.1.21
		 */
		public function register_plugin_for_activation() {
			if ( function_exists( 'YIT_Plugin_Licence' ) ) {
				YIT_Plugin_Licence()->register( YITH_WCPSC_INIT, YITH_WCPSC_SECRET_KEY, YITH_WCPSC_SLUG );
			}
		}

		/**
		 * Register plugins for update tab
		 *
		 * @return void
		 * @since 1.1.21
		 */
		public function register_plugin_for_updates() {
			if ( function_exists( 'YIT_Upgrade' ) ) {
				YIT_Upgrade()->register( YITH_WCPSC_SLUG, YITH_WCPSC_INIT );
			}
		}
    }
}

/**
 * Unique access to instance of YITH_WCPSC_Premium class
 *
 * @deprecated since 1.1.0 use YITH_WCPSC() instead
 * @return YITH_WCPSC_Premium
 * @since      1.0.0
 */
function YITH_WCPSC_Premium() {
    return YITH_WCPSC();
}