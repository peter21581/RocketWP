<?php

return [
	'title' => __( 'Global', 'it-l10n-ithemes-security-pro' ),
];
