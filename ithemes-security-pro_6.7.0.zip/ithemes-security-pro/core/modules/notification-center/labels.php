<?php

return [
	'title' => __( 'Notification Center', 'it-l10n-ithemes-security-pro' ),
];
