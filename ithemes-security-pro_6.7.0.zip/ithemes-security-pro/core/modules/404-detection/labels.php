<?php

return [
	'title' => __( '404 Detection', 'it-l10n-ithemes-security-pro' ),
];
