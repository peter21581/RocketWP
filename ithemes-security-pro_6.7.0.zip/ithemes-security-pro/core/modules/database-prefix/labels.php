<?php

return [
	'title' => __( 'Change Database Prefix', 'it-l10n-ithemes-security-pro' ),
];
