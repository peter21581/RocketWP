<?php

return [
	'title' => __( 'File Permissions', 'it-l10n-ithemes-security-pro' ),
];
