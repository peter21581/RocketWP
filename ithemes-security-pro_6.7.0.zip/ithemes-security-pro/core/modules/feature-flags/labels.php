<?php

return [
	'title' => __( 'Feature Flags', 'it-l10n-ithemes-security-pro' ),
];
