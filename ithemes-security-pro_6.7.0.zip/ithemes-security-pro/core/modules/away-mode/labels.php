<?php

return [
	'title' => __( 'Away Mode', 'it-l10n-ithemes-security-pro' ),
];
