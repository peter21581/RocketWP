<?php

return [
	'title' => __( 'Network Brute Force', 'it-l10n-ithemes-security-pro' ),
];
