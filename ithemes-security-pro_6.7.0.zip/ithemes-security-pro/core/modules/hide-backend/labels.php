<?php

return [
	'title' => __( 'Hide Backend', 'it-l10n-ithemes-security-pro' ),
];
