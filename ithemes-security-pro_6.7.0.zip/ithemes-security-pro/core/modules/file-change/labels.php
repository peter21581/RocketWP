<?php

return [
	'title' => __( 'File Change', 'it-l10n-ithemes-security-pro' ),
];
