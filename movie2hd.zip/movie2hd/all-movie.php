<?php /* Template Name: ALL MOVIE */ ?>
<?php get_header() ?>
<?php global $redux_demo; ?>
        <div class="page">
            <div class="page_layout page_margin_top clearfix">
              <?php
    $template = locate_template('banner/a.php');
    if ($template) {
        load_template($template);
    }
    ?>
                <div class="row">
                <?php 
                            
                            $template = locate_template('sidebar/left-sidebar.php');
                    
                                    if( $template ){
                                        load_template( $template );        
                                    }
                            ?>
                    <div class="blog column column_1_center">

                        <h2 class="box_header_newmovie th-font">หนังใหม่แนะนำ</h2>
                    
                        <div class="clearfix page_margin_top"></div>
                     
                        <div class="row">

                        <?php

                        //Protect against arbitrary paged values
                        $paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;

                        $args = array(
                            'posts_per_page' => 32,
                            'post_type' => 'post',
                            // 'paged' => ( get_query_var('page') ? get_query_var('page') : 1),

                            'paged' => ( get_query_var('paged') ? get_query_var('paged') : 1),
                        );
                        $the_query = new WP_Query( $args );
                        ?>
                        <?php if ( $the_query->have_posts() ) : ?>
                        <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
                        <?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>
                        <?php $cats = get_the_category(); ?>

                        <div class="blog column column_1_movie">
                                <div class="movie">
                                    <div class="movie-box">
                                        <div class="movie-title">
                                            <a href="<?php echo the_permalink() ?>" ><span><?php echo the_title() ?></span></a>
                                        </div>

                                        <div class="movie-imdb">
                                            <span class="icon"><span class="imdb"><img class="star" src="<?php echo get_template_directory_uri()?>/img/imdb_star_22x21.png"></span>
                                            <span><?php echo get_field('imbd')?></span></span>
                                        </div>
                                        <div class="movie-corner">
                                        <?php if(get_field('resolution') == 'hd') { ?>
                                            <span class="icon-type-hd"><span>HD</span></span>
                                                    <?php } else { ?>
                                                        <span class="icon-type-zm"><span>ZM</span></span>
                                                    <?php } ?>
                                        </div>
                                        <div class="movie-image">
                                            <a href="<?php echo the_permalink() ?>" >
                                                <img width="300" height="450" src="<?php echo $image[0]; ?>" class="attachment- size- wp-post-image" alt="" sizes="(max-width: 300px) 100vw, 300px" /> </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                                
                                
                                <?php else : ?>
                                <p style="text-align: center">- ไม่พบข้อมูล -</p>
                              
                
                     
                            <?php endif; ?> 
                        </div>
                        <?php
                        $big = 999999999; // need an unlikely integer
                        echo "<ul class='pagination clearfix page_margin_top' role='navigation'>";
                        echo  paginate_links( array(
                            'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                            'format' => '?paged=%#%',
                            'current' => max( 1, get_query_var('paged') ),
                            'total' => $the_query->max_num_pages,
                            'prev_text'          => '❮',
                            'next_text'          => '❯',
                        ) );
                        echo "</ul>";
                    
                        ?>
                        <?php
        $template = locate_template('banner/a10-12.php');
        if ($template) {
            load_template($template);
        }
        ?>
                    </div>


                    <?php 
                            
                            $template = locate_template('sidebar/right-sidebar.php');
                    
                                    if( $template ){
                                        load_template( $template );        
                                    }
                            ?>

                </div>
            
            </div>
        </div>
        <?php get_footer() ?>