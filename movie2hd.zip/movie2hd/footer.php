<?php global $redux_demo;
$date_now = date('m/d/Y');?>



<?php
if (is_single() && 'post' == get_post_type()) {
    $template = locate_template('banner/p_c.php');
}
else {
    $template = locate_template('banner/c.php');
}

if ($template) {
    load_template($template);
}
?>
<div class="footer_container">
  <div class="footer clearfix">
    <div class="row">
      <div class="Logo-Footer">
        <img src="<?php echo $redux_demo['opt-media-logobottom']['url']?>" class="custom-logo"> <a class="scroll_top th-font" href="#top" title="Scroll to top">Top</a></div>
      <p class="footer_content">
        <?php echo $redux_demo['opt-text-bottom1']?></p>
    </div>
    <div class="row copyright_row">
      <div class="column th-font">
        <?php echo $redux_demo['opt-text-bottom2']?>
      </div>
    </div>
  </div>
</div>
</div>
<div class="background_overlay"></div>

<?php wp_footer()?>
</body>
</html>