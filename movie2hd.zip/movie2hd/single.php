<?php get_header()?>
<?php
global $redux_demo;
$date_now = date('Y-m-d');
?>
<div class="page">

  <div class="page_layout page_margin_top clearfix">
    <?php
    $template = locate_template('banner/p_a.php');
    if ($template) {
        load_template($template);
    }
    ?>
    <div class="row">
      <?php
      $template = locate_template('sidebar/left-sidebar.php');

      if ($template) {
          load_template($template);
      }
      ?>
      <div class="blog column column_1_center">
        <?php
// Start the loop.
        while (have_posts()) : the_post();
            ?>
            <?php $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'single-post-thumbnail');?>
            <?php $cats = get_the_category();?>
            <div class="box-header">
              <div class="title">
                <a href="https://www.google.co.th/search?hl=th&amp;q=<?php echo site_url()?> <?php echo the_title()?>" title="<?php echo the_title()?>" target="_blank" class="google-search"  >
                  <img src="<?php echo get_template_directory_uri()?>/img/google.png">
                </a>
                <h1><a href="<?php echo the_permalink()?>" title="<?php echo the_title()?>" ><?php echo the_title()?></a></h1>
              </div>
              <div class="bread_crumb th-font">
                <span><a href="<?php echo site_url()?>" >หน้าแรก</a></span>
                <?php
                for ($i = 0; $i < count($cats); $i++) {
                    ?>
                    <span><a href="<?php echo get_category_link($cats[$i]->term_id);?>" ><?php echo $cats[$i]->name;?></a></span>


                    <?php
                }
                ?>

              </div>
            </div>
            <div class="row page_margin_top">
              <div class="blog column_movie_thumbnail">
                <img width="300" height="429" src="<?php echo $image[0];?>" class="attachment- size- wp-post-image" alt="" sizes="(max-width: 300px) 100vw, 300px">
              </div>
              <div class="blog column_1_youtube">
                <?php echo get_field('trailer')?>
              </div>
            </div>
            <div class="row">
              <div class="blog column" style=" width: 100%; ">
                <?php if ( date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsa7'])) >= $date_now) {?>
                    <a href="<?php echo $redux_demo['opt-media-adsa7-link']?>" target="_blank" >
                      <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsa7']['url']?>" width="100%" alt="" title="" style=" height: 180px; ">
                    </a>
                <?php }?>
                <div class="clear" style="clear: both;padding-bottom: 5px;"></div>
                <?php if ( date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsa8'])) >= $date_now) {?>
                    <a href="<?php echo $redux_demo['opt-media-adsa8-link']?>" target="_blank" >
                      <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsa8']['url']?>" width="100%" alt="" title="" style=" height: 180px; ">
                    </a>
                <?php }?>
                <div class="clear" style="clear: both;padding-bottom: 5px;"></div>
                <?php if ( date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsa9'])) >= $date_now) {?>
                    <a href="<?php echo $redux_demo['opt-media-adsa9-link']?>" target="_blank" >
                      <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsa9']['url']?>" width="100%" alt="" title="" style=" height: 180px; ">
                    </a>
                <?php }?>
              </div>
          <?php endwhile;?>
          <div class="movie-description th-font">
            <div class="th-font">
              <a href="<?php echo site_url()?>" >
                ดูหนังออนไลน์
              </a>
              <a href="<?php echo the_permalink()?>" >
                <strong><?php echo the_title()?> </strong>
              </a>
            </div>
            <div class="imdb-rating">
              <div class="imdb-rating-content">
                <span> <?php echo get_field('imbd')?></span>/10
              </div>
            </div>
          </div>

        </div>

        <div class="row page_margin_top">
        <!--<iframe rel="nofollow" id="frame" src="<?php echo get_field('file');?>" width="100%" height="500" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true" scrolling="no" frameborder="0"></iframe>--> 


          <script src="//ssl.p.jwpcdn.com/player/v/7.12.13/jwplayer.js"></script>
          <script type="text/javascript">jwplayer.key = "itWTHIhJdAIEfyNdzc0HeaZWvkzjhvdQU3VtAw==";</script>


          <?php


          $url1 = get_field('file');
$host_ok = explode('https://moviezt1.b-cdn.net',$url1);
          
$securityKey = 'c8c0a0b5-6eb1-4061-b26e-829f4cc58c40';
$path = $host_ok[1];

// Set the time of expiry to one hour from now
$expires = time() + 7200; 

// Generate the token
$hashableBase = $securityKey.$path.$expires;

// If using IP validation
// $hashableBase .= "146.14.19.7";

$token = md5($hashableBase);
$token = base64_encode($token);
$token = strtr($token, '+/', '-_');
$token = str_replace('=', '', $token);  

// Generate the URL
$url = "https://moviezt1.b-cdn.net{$path}?token={$token}&expires={$expires}";

$url = get_field('file');



          ?>
          <div id="player">
            <p class="js-player-load text-center">
              <i class="fas fa-circle-notch fa-spin fa-3x"></i>
            </p>
          </div>
          <div class="ad-player-skip">
            <button class="js-btn-init btn btn-primary th-font btn-lg">
              <div>
                <span id="js-text-go"></span> <span id="js-timeleft"></span>
              </div>
            </button>
          </div>
          <div class="ad-player-link">
            <a class="js-btn-init btn btn-primary th-font btn-sm more-link" target="_blank">
              <div>
                <span id="js-text-go-link">สมัครสมาชิก</span>
              </div>
            </a>
          </div>
          <div class="go-hard">
            <div class="go-player">
              <div>
                <button class="btn btn-lg btn-danger th-font js-btn-go-player-exit">
                  <div>
                    <i class="fas fa-times fa-2x"></i>
                  </div>
                </button>
                <a href="<?=$redux_demo['opt-link-firstplayer'];?>" rel="noopener noreferrer nofollow" target="_blank" class="btn btn-dark th-font js-btn-go-player">
                  <div>
                    สมัครสมาชิก
                  </div>
                </a>
              </div>
              <div>
                <img src="<?=$redux_demo['opt-media-firstplayer']['url'];?>" class="js-go-player-banner" alt="saclub888" width="400">
              </div>
            </div>
          </div>

          <?php
          $first_banner = ( date('Y-m-d',strtotime($redux_demo['opt-datepicker-firstplayer'])) >= $date_now) ? "true" : "false";
          $array_as = array();
          for ($ia = 1; $ia <= 4; $ia++) {
              $video = 'opt-media-videoads'.$ia;
              $dateex = 'opt-datepicker-videoads'.$ia;
              $linkreg = 'opt-media-videoads'.$ia.'-link';
              if ( date('Y-m-d',strtotime($redux_demo[$dateex])) >= $date_now) {
                  $array_a = array();
                  $array_a[video] = $redux_demo[$video]['url'];
                  $array_a[link] = $redux_demo[$linkreg];
                  $array_a[link_label] = "";
                  $array_a[can_skip] = "0";
                  $array_a[skip] = $redux_demo['opt-timeskip'];
                  $array_a[website_id] = "";
                  $array_as[] = $array_a;
              }
          }

          $json_x = json_encode($array_as);
          ?>
          <link rel="stylesheet" href="<?php echo get_template_directory_uri()?>/css/style-player.css">
          <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
          <script src="https://unpkg.com/axios/dist/axios.min.js" ></script>
          <script>
              var poster = '<?php echo $redux_demo['opt-media-coverplayer']['url'];?>';
              var url = '<?=$url?>';
              var go = JSON.parse('<?=$json_x;?>');
              var go_player_hard = <?=$first_banner;?>;
          </script>   
          <script src="<?php echo get_template_directory_uri()?>/js/movie-ok.js?id=<?=time();?>" ></script>
        </div>
        <?php
        $template = locate_template('banner/p_a10-12.php');
        if ($template) {
            load_template($template);
        }
        ?>



        <div class="row page_margin_top">
          <h4 class="box_header th-font">แสดงความคิดเห็น</h4>
          <div class="bg-facebook page_margin_top">
            <div id="fb-root"></div>
            <script async defer crossorigin="anonymous" src="https://connect.facebook.net/th_TH/sdk.js#xfbml=1&version=v6.0&appId=735926713247947&autoLogAppEvents=1"></script>
            <div class="fb-comments" data-href="<?php echo site_url()?>" data-width="100%" data-numposts="5" data-colorscheme="dark"></div>
            <style>
              iframe {
                width: 100%!important
              }
            </style>
          </div>
        </div>
        <div class="row page_margin_top">
          <h4 class="box_header th-font">สุ่มหนังเรื่องอื่นๆ</h4>
          <div class="clearfix page_margin_top"></div>
          <div class="row">
            <?php
//Protect against arbitrary paged values
            $paged = ( get_query_var('paged') ) ? absint(get_query_var('paged')) : 1;

            $args = array(
              'posts_per_page' => 4,
              'post_type' => 'post',
              'orderby' => 'rand',
              'paged' => ( get_query_var('page') ? get_query_var('page') : 1),
                // 'paged' => ( get_query_var('paged') ? get_query_var('paged') : 1),
            );
            $the_query = new WP_Query($args);
            ?>
            <?php if ($the_query->have_posts()) :?>
                <?php while ($the_query->have_posts()) : $the_query->the_post();?>
                    <?php $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'single-post-thumbnail');?>
                    <div class="blog column column_1_movie">
                      <div class="movie">
                        <div class="movie-box">
                          <div class="movie-title">
                            <a href="<?php echo the_permalink()?>" ><span><?php echo the_title()?></span></a>
                          </div>

                          <div class="movie-imdb">
                            <span class="icon"><span class="imdb">
                                <img class="star" src="<?php echo get_template_directory_uri()?>/img/imdb_star_22x21.png"></span> <span><?php echo get_field('imbd')?></span></span> </div>
                          <div class="movie-corner">
                            <?php if (get_field('resolution') == 'hd') {?>
                                <span class="icon-type-hd"><span>HD</span></span>
                                <?php
                            }
                            else {
                                ?>
                                <span class="icon-type-zm"><span>ZM</span></span>
                            <?php }?>
                          </div>
                          <div class="movie-image">
                            <a href="<?php echo the_permalink()?>" >
                              <img width="200" height="286" src="<?php echo $image[0];?>" class="attachment- size- wp-post-image" alt="" sizes="(max-width: 200px) 100vw, 200px"> </a>
                          </div>
                        </div>
                      </div>
                    </div>


                <?php endwhile;?>


            <?php else :?>
                <p style="text-align: center">- ไม่พบข้อมูล -</p>



            <?php endif;?> 

          </div>
        </div>
      </div>


      <?php
      $template = locate_template('sidebar/right-sidebar.php');

      if ($template) {
          load_template($template);
      }
      ?>

    </div>
  </div>
</div>



<?php?>




<?php
get_footer()?>