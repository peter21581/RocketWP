<!DOCTYPE HTML>
<?php global $redux_demo; ?>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=980" />
    <meta name="viewport" content="width=device-width, maximum-scale=3.0, minimum-scale=0.3">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <?php if ( is_home() ) { ?>
        <title><?php echo get_bloginfo(); ?></title>

    <?php } else  { ?>
        <title><?php echo the_title() ?> <?php single_cat_title(); ?> | <?php echo get_bloginfo(); ?></title>

    <?php } ?>
    
    <meta name="description" content="ดูหนังออนไลน์มันส์ๆ มีครบทุกเรื่อง หนัง ซี่รี่ส์ Netflix หนังชนโรงดูฟรี ดูแบบHD 4Kก็มีครบ หนังคมชัดระดับ Blueray ดูหนังฟรีผ่านมือถือ Tablet ดูหนังผ่านเว็บ" />

    <link rel="stylesheet" href="<?php echo get_template_directory_uri()?>/css/style.css" media="all" />
    
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Prompt&#038;display=swap&#038;ver=1.0' type='text/css' media='all' />

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
    <?php wp_head() ?>
    <style type="text/css">
        p a {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        strong {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .box_header {
            border-left: 3px solid <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .about_subtitle {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .header h1 {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .header h1 a {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .sf-menu li:hover,
        .sf-menu li.selected,
        .sf-menu li.submenu:hover {
            border-top-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>;
        }
        .mobile-menu li.selected ul li.selected ul li.selected a {
            background: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .mobile-menu-switch {
            border: 2px solid <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }

        .mobile-menu-switch .line {
            background: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }

        .mobile-menu-switch:hover {
            background: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        a.slider_control:hover {
            background-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }

        .slider_posts_list .slider_posts_list_bar {
            background-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .footer .post .comments_number:hover {
            background: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .footer .post .comments_number:hover .arrow_comments {
            border-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?> transparent!important
        }
        .post_details li.category {
            background: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .blog ul.post_details.simple li.category a {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }

        .post.single .post_details a {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }

        .dropcap .dropcap_label.active {
            background-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }

        .taxonomies a:hover {
            background: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
            border-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .taxonomies a.selected {
            background: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
            border-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }

        .review_summary .number {
            border: 2px solid <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .value_container .value_bar {
            background: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .announcement .expose {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .read_more .arrow {
            background: <?php echo $redux_demo['opt-color-headbg']['color'] ?> url(./icons/navigation/call_to_action_arrow.png) no-repeat!important;
        }
        #cancel_comment {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        span.page-numbers.current {
            background: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        a.page-numbers:hover {
            background: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .tabs_navigation li a:hover,
        .tabs_navigation li a.selected,
        .tabs_navigation li.ui-tabs-active a {
            background: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }

        .tabs_navigation li.ui-tabs-active span {
            border-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?> transparent!important;
        }
        .tabs_navigation.small li a:hover,
        .tabs_navigation.small li a.selected,
        .tabs_navigation.small li.ui-tabs-active a {
            border-bottom: 3px solid <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .accordion .ui-accordion-header.ui-state-active {
            background-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
            border-bottom-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }

        .accordion .ui-accordion-header:hover .ui-accordion-header-icon {
            background: <?php echo $redux_demo['opt-color-headbg']['color'] ?> url(./icons/navigation/accordion_arrow_down_hover.png) no-repeat 0 0!important
        }
        .icon.fullscreen:hover {
            background-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .colors .form {
            background-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .colors .mobile {
            background-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .more.active:hover {
            border: 2px solid <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }

        .more.active,
        .more:hover {
            background: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
            border-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .th-font a:hover {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .imdb {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .js-player-load {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .blog.column.column_1_movie:hover {
            border-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .blog.column.column_1_right_year .Title {
            border-left: 3px solid <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .blog.column.column_1_left_year .Title {
            border-left: 3px solid <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .blog.column.column_1_left_year li a:hover {
            background-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .content-tags a:hover {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .style_3 .sf-menu a:hover {
            background-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .style_10 .sf-menu li.submenu:hover a {
            background-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
            border-top-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
            border-bottom-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .style_3 .sf-menu li {
            border-top-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .style_4 .sf-menu li.submenu:hover a {
            border-top-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .style_10 .sf-menu a:hover {
            background-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .bread_crumb span a:hover {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .sf-menu li.submenu:hover a {
            border-top-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .recommend a.selected {
            background: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
            border-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .mobile-menu-switch {
            border-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .mobile-menu li.selected ul li.selected ul li.selected a {
            background-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .footer .post .comments_number:hover .arrow_comments {
            border-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?> transparent!important
        }
        p a {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .title h1 a:hover {
            color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .box_header_newmovie {
            border-left: 3px solid <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .box-header {
            border-left: 3px solid <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .blog.column.column_1_right_year li a:hover {
            background-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important;
        }
        .gallery_popup .slider_navigation .slider_control a:hover {
            background-color: <?php echo $redux_demo['opt-color-headbg']['color'] ?>!important
        }
        .site-title a,
        .site-description {
            color: #000000;
        }
    </style>
</head>

<body class="pattern_8">
    <div class="site_container boxed">
        <div class="header_top_bar_container clearfix style_4">
            <div class="header_top_bar">
                <form class="search" method="get" id="searchform" class="searchform" action="<?php echo site_url() ?>/search_movie" autocomplete="off">
                    <input autocomplete="off" type="search" name="keyword" placeholder="พิมพ์ชื่อหนัง..." value="" value="" class="search_input hint th-font">
                    <input type="submit" class="search_submit" value="">
                </form>
                <ul class="social_icons clearfix">
                    <li>
                        <a target="_blank" href="<?php echo $redux_demo['opt-facebook'] ?>" class="social_icon facebook" title="facebook">&nbsp;</a>
                    </li>
                </ul>
                <div class="latest_news_scrolling_list_container">
                    <ul>
                        <h1>
                            <li class="category th-font"><?php echo $redux_demo['opt-text-top'] ?></li>
                        </h1>
                    </ul>
                </div>
            </div>
        </div>
        <div class="header_container style_2 small">
            <div class="header clearfix">
                <div class="logo">
                    <a href="<?php echo site_url(); ?>" rel="home" ><img src="<?php echo $redux_demo['opt-media-logotop']['url'] ?>" alt="ดูหนังฟรี ดูหนังออนไลน์ ดูหนังใหม่ หนังHD หนังชนโรง" class="img-logo"></a>
                </div>

            </div>
        </div>
        <div class="menu_container clearfix">
            <nav>
            <?php
                wp_nav_menu( array( 
                    'container'       => 'ul',
                'theme_location' => 'main_menu', 
                'menu_class'      => 'menu-category-list',
                'container_class' => 'menu',
                'container_id'    => 'menu-mainmenu',
                'menu_id'         => 'menu-mainmenu',
                'items_wrap'      => '<ul id="sf-menu" class="sf-menu">%3$s</ul>',
                'container_class' => 'menu_container clearfix' ) ); 
                ?>
                </nav>
        </div>
       
        