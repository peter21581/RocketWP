<?php get_header() ?>
<?php global $redux_demo; ?>
        <div class="container">
            <div class="content">

           <?php 

           $template = locate_template('banner/a.php');
 
                if( $template ){
                    load_template( $template );        
                }
           ?>

                <div class="content-movie">
                    <?php 

                    $template = locate_template('sidebar/left-sidebar.php');

                        if( $template ){
                            load_template( $template );        
                        }
                    ?>

                    <section class="contentmovie">
                        <div class="movietext">
                            <h1><?php single_cat_title(); ?></h1>
                        </div>
                        <div class="movie">
                            <div class="grid-movie">
                            <?php
                        
                            //Protect against arbitrary paged values
                            $paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;

                            $args = array(
                                'posts_per_page' => 32,
                                'post_type' => 'post',
                
                                //'paged' => ( get_query_var('page') ? get_query_var('page') : 1),

                                 'paged' => ( get_query_var('paged') ? get_query_var('paged') : 1),
                            );
                            $the_query = new WP_Query( $args );
                            ?>
                            <?php if ( $the_query->have_posts() ) : ?>
                                <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
                            <?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>
                            <?php $cats = get_the_category(); ?>
                                <div class="box" style="position: relative;
                                overflow: hidden;">
                                    <a href="<?php echo the_permalink() ?>">
                                        <div class="box-img">
                                            <img width="350" height="465" src="<?php echo $image[0]; ?>" class="attachment-full size-full wp-post-image" alt="ดูหนังออนไลน์ฟรี <?php the_title() ?>" sizes="(max-width: 350px) 100vw, 350px" />
                                            <div class="figure-box">
                                                <span class="info1"><?php echo get_field('imbd')?><img class="star" src="https://ia.media-imdb.com/images/G/01/imdb/plugins/rating/images/imdb_star_22x21.png"></span>
                                                <?php if(get_field('resolution') == 'hd') { ?>
                                                        <img src="<?php echo get_template_directory_uri() ?>/img/hd-logo.png" style="width:50px;height:auto">
                                                    <?php } else { ?>
                                                        <img src="<?php echo get_template_directory_uri() ?>/img/zoom-logo.png" style="width:50px;height:auto">
                                                    <?php } ?>
                                            </div>
                                        </div>
                                        <div class="p-box">
                                            <div class="p1">
                                            <?php if(get_field('sound') == 'th') { ?>
                                                เสียงไทย 
                                            <?php } else { ?>
                                                Sound Track 
                                            <?php } ?> 
                                    <a href="<?php echo site_url() ?>/fillter-year?y=<?php echo get_field('year') ?>" rel="tag"><?php echo get_field('year') ?></a> </div>
                                            <div class="p2"><?php echo the_title() ?></div>
                                        </div>
                                    </a>
                                </div>
                                
                              
                                <?php endwhile; ?>
                                
                                <?php else : ?>
                                <p style="text-align: center">- ไม่พบข้อมูล -</p>
                              
                
                     
                            <?php endif; ?> 
                            </div>
                            <?php 
           
                            $template = locate_template('banner/a5-7.php');
                    
                                    if( $template ){
                                        load_template( $template );        
                                    }
                            ?>
                  
                    <div class="col-md-12">
                        
                        <?php
                        $big = 999999999; // need an unlikely integer
                        echo "<nav class='navigation pagination' role='navigation' aria-label='Posts'><div class='nav-links'>";
                        echo  paginate_links( array(
                            'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                            'format' => '?paged=%#%',
                            'current' => max( 1, get_query_var('paged') ),
                            'total' => $the_query->max_num_pages
                        ) );
                        echo "</div></nav>";
                    
                        ?>
                          <?php
        $template = locate_template('banner/a10-12.php');
        if ($template) {
            load_template($template);
        }
        ?>
                        </div>
                        
                    </section>
                    <?php 
                            
                            $template = locate_template('sidebar/right-sidebar.php');
                    
                                    if( $template ){
                                        load_template( $template );        
                                    }
                            ?>
                </div>
            </div>
        </div>
        <?php 
                            
                            $template = locate_template('banner/c.php');
                    
                                    if( $template ){
                                        load_template( $template );        
                                    }
                            ?>

     <?php get_footer() ?>