$(document).ready(function() {
    $(".comment").click(function() {
        if ($(".comment").hasClass("active")) {} else { $(".trailer").removeClass("active");
            $(".ss").removeClass("active");
            $(".comment").addClass("active"); }
    });
    $(".trailer").click(function() {
        if ($(".trailer").hasClass("active")) {} else { $(".trailer").addClass("active");
            $(".ss").removeClass("active");
            $(".comment").removeClass("active"); }
    });
    $(".ss").click(function() {
        if ($(".ss").hasClass("active")) {} else { $(".trailer").removeClass("active");
            $(".ss").addClass("active");
            $(".comment").removeClass("active"); }
    });
    $('.link-support button').click(function() { $(this).addClass("active");
        $('.link-main button').removeClass("active"); });
    $('.link-main button').click(function() { $(this).addClass("active");
        $('.link-support button').removeClass("active"); });
});
$(document).ready(function() { $(".comment").click(function() { $(".show-trailer").hide();
        $(".show-comment").show();
        $(".show-ss").hide(); });
    $(".trailer").click(function() { $(".show-trailer").show();
        $(".show-comment").hide();
        $(".show-ss").hide(); });
    $(".ss").click(function() { $(".show-trailer").hide();
        $(".show-comment").hide();
        $(".show-ss").show(); }); });
$(document).ready(function() { var model = $(".model"); var img = $("#img-ss .attachment-full"); var modelImg = $("#img01");
    $(img).click(function() { var img_path = this.src;
        $(model).css('display', 'block');
        $(modelImg).attr('src', img_path);
        $("body").css({ "position": "fixed", "overflow": "hidden" }); });
    $(".close").click(function() { $(model).css('display', 'none');
        $("body").css({ "position": "unset", "overflow": "unset" }); }) });
$(document).ready(function() { $(".ad-float-bottom li").append('<span class="close-ad">X</span>');
    $(".ad-float-left1 li").append('<span class="close-ad">X</span>');
    $(".ad-float-left2 li").append('<span class="close-ad">X</span>');
    $(".ad-float-right1 li").append('<span class="close-ad">X</span>');
    $(".ad-float-right2 li").append('<span class="close-ad">X</span>'); });
$(document).ready(function() { $(".ad-float-bottom .close-ad").click(function() { $(".ad-float-bottom").hide(); });
    $(".ad-float-left1 .close-ad").click(function() { $(".ad-float-left1").hide(); });
    $(".ad-float-left2 .close-ad").click(function() { $(".ad-float-left2").hide(); });
    $(".ad-float-right1 .close-ad").click(function() { $(".ad-float-right1").hide(); });
    $(".ad-float-right2 .close-ad").click(function() { $(".ad-float-right2").hide(); }); });
$(document).ready(function() { $('.button-sub-1').click(function() { $('#movie').attr("src", $(this).data('video-embed')); });
    $('.button-sub-2').click(function() { $('#movie').attr("src", $(this).data('video-embed')); }); });
$(document).ready(function() { var winHeight = $(window).height();
    $(window).scroll(function() { $("ad-float-left1").css("bottom", $(window).scrollTop() + (winHeight - 30) + "px"); }); });
$('.link-support button').click(function() { $('.button-sub-1').hide();
    $('.button-sub-2').hide();
    $('.movie iframe#movie').attr('src', $('.link-support').data('link-support')); });
$('.link-main button').click(function() { $('.button-sub-1').show();
    $('.button-sub-2').show();
    $('.movie iframe#movie').attr('src', $('.link-main').data('link-main')); });