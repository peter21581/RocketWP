! function(e) {
    var t = {};

    function n(r) {
        if (t[r]) return t[r].exports;
        var o = t[r] = {
            i: r,
            l: !1,
            exports: {}
        };
        return e[r].call(o.exports, o, o.exports, n), o.l = !0, o.exports
    }
    n.m = e, n.c = t, n.d = function(e, t, r) {
        n.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: r
        })
    }, n.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, n.t = function(e, t) {
        if (1 & t && (e = n(e)), 8 & t) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var r = Object.create(null);
        if (n.r(r), Object.defineProperty(r, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var o in e) n.d(r, o, function(t) {
                return e[t]
            }.bind(null, o));
        return r
    }, n.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return n.d(t, "a", t), t
    }, n.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, n.p = "/", n(n.s = 1)
}({
    1: function(e, t, n) {
        e.exports = n("Hl2H")
    },
    "2SVd": function(e, t, n) {
        "use strict";
        e.exports = function(e) {
            return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(e)
        }
    },
    "5oMp": function(e, t, n) {
        "use strict";
        e.exports = function(e, t) {
            return t ? e.replace(/\/+$/, "") + "/" + t.replace(/^\/+/, "") : e
        }
    },
    "8oxB": function(e, t) {
        var n, r, o = e.exports = {};

        function i() {
            throw new Error("setTimeout has not been defined")
        }

        function s() {
            throw new Error("clearTimeout has not been defined")
        }

        function a(e) {
            if (n === setTimeout) return setTimeout(e, 0);
            if ((n === i || !n) && setTimeout) return n = setTimeout, setTimeout(e, 0);
            try {
                return n(e, 0)
            } catch (t) {
                try {
                    return n.call(null, e, 0)
                } catch (t) {
                    return n.call(this, e, 0)
                }
            }
        }! function() {
            try {
                n = "function" == typeof setTimeout ? setTimeout : i
            } catch (e) {
                n = i
            }
            try {
                r = "function" == typeof clearTimeout ? clearTimeout : s
            } catch (e) {
                r = s
            }
        }();
        var u, c = [],
            l = !1,
            f = -1;

        function d() {
            l && u && (l = !1, u.length ? c = u.concat(c) : f = -1, c.length && p())
        }

        function p() {
            if (!l) {
                var e = a(d);
                l = !0;
                for (var t = c.length; t;) {
                    for (u = c, c = []; ++f < t;) u && u[f].run();
                    f = -1, t = c.length
                }
                u = null, l = !1,
                    function(e) {
                        if (r === clearTimeout) return clearTimeout(e);
                        if ((r === s || !r) && clearTimeout) return r = clearTimeout, clearTimeout(e);
                        try {
                            r(e)
                        } catch (t) {
                            try {
                                return r.call(null, e)
                            } catch (t) {
                                return r.call(this, e)
                            }
                        }
                    }(e)
            }
        }

        function h(e, t) {
            this.fun = e, this.array = t
        }

        function v() {}
        o.nextTick = function(e) {
            var t = new Array(arguments.length - 1);
            if (arguments.length > 1)
                for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
            c.push(new h(e, t)), 1 !== c.length || l || a(p)
        }, h.prototype.run = function() {
            this.fun.apply(null, this.array)
        }, o.title = "browser", o.browser = !0, o.env = {}, o.argv = [], o.version = "", o.versions = {}, o.on = v, o.addListener = v, o.once = v, o.off = v, o.removeListener = v, o.removeAllListeners = v, o.emit = v, o.prependListener = v, o.prependOnceListener = v, o.listeners = function(e) {
            return []
        }, o.binding = function(e) {
            throw new Error("process.binding is not supported")
        }, o.cwd = function() {
            return "/"
        }, o.chdir = function(e) {
            throw new Error("process.chdir is not supported")
        }, o.umask = function() {
            return 0
        }
    },
    "9rSQ": function(e, t, n) {
        "use strict";
        var r = n("xTJ+");

        function o() {
            this.handlers = []
        }
        o.prototype.use = function(e, t) {
            return this.handlers.push({
                fulfilled: e,
                rejected: t
            }), this.handlers.length - 1
        }, o.prototype.eject = function(e) {
            this.handlers[e] && (this.handlers[e] = null)
        }, o.prototype.forEach = function(e) {
            r.forEach(this.handlers, (function(t) {
                null !== t && e(t)
            }))
        }, e.exports = o
    },
    BEtg: function(e, t) {
        e.exports = function(e) {
            return null != e && null != e.constructor && "function" == typeof e.constructor.isBuffer && e.constructor.isBuffer(e)
        }
    },
    CgaS: function(e, t, n) {
        "use strict";
        var r = n("JEQr"),
            o = n("xTJ+"),
            i = n("9rSQ"),
            s = n("UnBK");

        function a(e) {
            this.defaults = e, this.interceptors = {
                request: new i,
                response: new i
            }
        }
        a.prototype.request = function(e) {
            "string" == typeof e && (e = o.merge({
                url: arguments[0]
            }, arguments[1])), (e = o.merge(r, {
                method: "get"
            }, this.defaults, e)).method = e.method.toLowerCase();
            var t = [s, void 0],
                n = Promise.resolve(e);
            for (this.interceptors.request.forEach((function(e) {
                    t.unshift(e.fulfilled, e.rejected)
                })), this.interceptors.response.forEach((function(e) {
                    t.push(e.fulfilled, e.rejected)
                })); t.length;) n = n.then(t.shift(), t.shift());
            return n
        }, o.forEach(["delete", "get", "head", "options"], (function(e) {
            a.prototype[e] = function(t, n) {
                return this.request(o.merge(n || {}, {
                    method: e,
                    url: t
                }))
            }
        })), o.forEach(["post", "put", "patch"], (function(e) {
            a.prototype[e] = function(t, n, r) {
                return this.request(o.merge(r || {}, {
                    method: e,
                    url: t,
                    data: n
                }))
            }
        })), e.exports = a
    },
    DfZB: function(e, t, n) {
        "use strict";
        e.exports = function(e) {
            return function(t) {
                return e.apply(null, t)
            }
        }
    },
    HSsa: function(e, t, n) {
        "use strict";
        e.exports = function(e, t) {
            return function() {
                for (var n = new Array(arguments.length), r = 0; r < n.length; r++) n[r] = arguments[r];
                return e.apply(t, n)
            }
        }
    },
    Hl2H: function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("MQBw"),
            o = n("vDqi");
        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content")
            }
        }), jwplayer.key = "itWTHIhJdAIEfyNdzc0HeaZWvkzjhvdQU3VtAw==";
        var i = jwplayer("player"),
            s = !0,
            a = !1,
            u = !0,
            c = 0,
            l = go.length,
            f = !1,
            d = 0,
            p = !0,
            h = !1,
            v = "",
            g = [],
            m = {
                segments: {
                    forwardSegmentCount: 50
                },
                loader: {
                    cachedSegmentExpiration: 864e5,
                    cachedSegmentsCount: 1e3,
                    requiredSegmentsPriority: 3,
                    httpDownloadMaxPriority: 9,
                    httpDownloadProbability: .06,
                    httpDownloadProbabilityInterval: 1e3,
                    httpDownloadProbabilitySkipIfNoPeers: !0,
                    p2pDownloadMaxPriority: 50,
                    httpFailedSegmentTimeout: 1e3,
                    simultaneousP2PDownloads: 20,
                    simultaneousHttpDownloads: 3,
                    httpDownloadInitialTimeout: 12e4,
                    httpDownloadInitialTimeoutPerSegment: 17e3,
                    httpUseRanges: !0,
                    trackerAnnounce: ["wss://p2p.laos-tech.com", "wss://tracker.novage.com.ua"]
                }
            };
        0 != l ? (i = jwplayer("player")).setup({
            playlist: [{
                image: poster,
                sources: [{
                    file: go[c].video
                }]
            }],
            allowfullscreen: !0,
            width: "100%",
            height: "100%",
            aspectratio: "16:9",
            cast: {},
            preload: "metadata"
        }) : ($(".js-player-load").show(), 
        i.setup({
                                file: url,
                                image: poster,
                                allowfullscreen: !0,
                                width: "100%",
                                height: "100%",
                                aspectratio: "16:9",
                                preload: "metadata",
                                cast: {}
                            })
                );

        function y(e, t) {
            return void 0 !== e.data.resolution_1080 && (0 <= e.data.resolution_1080.indexOf("index.m3u8") ? (t.push({
                file: e.data.resolution_1080
            }), v = e.data.resolution_1080, h = !0) : t.push({
                type: "video/mp4",
                label: "1080p",
                file: e.data.resolution_1080
            })), void 0 !== e.data.resolution_720 && t.push({
                type: "video/mp4",
                label: "720p",
                file: e.data.resolution_720
            }), void 0 !== e.data.resolution_360 && t.push({
                type: "video/mp4",
                label: "360p",
                file: e.data.resolution_360
            }), t
        }

        function E() {
            if (f || 1 != l) {
                if (c < l) return $("#js-text-go").text("กำลังโหลด..."), i.load([{
                    type: "video/mp4",
                    file: go[c].video
                }]), void i.play();
                i.setControls(!0), i.setup({
                                file: url,
                                image: poster,
                                allowfullscreen: !0,
                                width: "100%",
                                height: "100%",
                                aspectratio: "16:9",
                                preload: "none",
                                cast: {
                                    customAppId: "481EA5C8"
                                }
                            }),
                        i.play(), i.play(), $(".ad-player-skip").hide(), $(".ad-player-link").hide(), s = !1, a = !1
            } else {
                $("#js-text-go").text("กำลังโหลด...");
                var e = setInterval((function() {
                    f && (E(), clearInterval(e))
                }), 1e3)
                i.setup({
                                file: url,
                                image: poster,
                                allowfullscreen: !0,
                                width: "100%",
                                height: "100%",
                                aspectratio: "16:9",
                                preload: "metadata",
                                cast: {}
                            }), i.play(), $(".ad-player-skip").hide(), $(".ad-player-link").hide()
            }
        }

        function _(e, t, n) {
            jwplayer("player").setup({
                playlist: [{
                    image: n,
                    sources: t
                }],
                allowfullscreen: !0,
                width: "100%",
                height: "100%",
                aspectratio: "16:9",
                preload: "none",
                cast: {}
            })
        }
        i.on("cast", (function(e) {
            e.active ? u = !1 : e.active || u || i.stop()
        })), i.on("complete", (function(e) {
            E()
        })), i.on("firstFrame", (function() {

                $("#js-text-go").text("กดข้ามโฆษณาใน"), $("#js-timeleft").text(go[c].skip), $(".more-link").attr("href", go[c].link), i.setControls(!1), a = !0, $(".ad-player-skip").show(), $(".ad-player-link").show(), d = go[c].skip - 1;
                var e = setInterval((function() {
                    d <= go[c - 1].can_skip ? ($("#js-text-go").text("ข้ามโฆษณา"), $("#js-timeleft").text(d), $(".js-btn-init").addClass("js-btn-skip")) : $("#js-timeleft").text(d), d <= 0 && ($("#js-timeleft").text(""), clearInterval(e)), d -= 1
                }), 1e3);
                c++
            
            
        })), i.on("displayClick", (function() {
            a && window.open(go[c - 1].link, "_blank")
        })), $(".ad-player-skip").on("click", ".js-btn-skip", (function() {
            E(), $(".js-btn-init").removeClass("js-btn-skip")
        })), go_player_hard && (i.on("ready", (function() {
            $(".go-hard").show(), $("body").on("click", ".js-go-player-banner", (function() {
                window.open($(".js-btn-go-player").attr("href"), "_blank")
            }))
        })), $("body").on("click", ".js-btn-go-player-exit", (function() {
            $(".go-player").hide(), $(".go-hard").hide()
        })))
    },
    JEQr: function(e, t, n) {
        "use strict";
        (function(t) {
            var r = n("xTJ+"),
                o = n("yK9s"),
                i = {
                    "Content-Type": "application/x-www-form-urlencoded"
                };

            function s(e, t) {
                !r.isUndefined(e) && r.isUndefined(e["Content-Type"]) && (e["Content-Type"] = t)
            }
            var a, u = {
                adapter: ("undefined" != typeof XMLHttpRequest ? a = n("tQ2B") : void 0 !== t && (a = n("tQ2B")), a),
                transformRequest: [function(e, t) {
                    return o(t, "Content-Type"), r.isFormData(e) || r.isArrayBuffer(e) || r.isBuffer(e) || r.isStream(e) || r.isFile(e) || r.isBlob(e) ? e : r.isArrayBufferView(e) ? e.buffer : r.isURLSearchParams(e) ? (s(t, "application/x-www-form-urlencoded;charset=utf-8"), e.toString()) : r.isObject(e) ? (s(t, "application/json;charset=utf-8"), JSON.stringify(e)) : e
                }],
                transformResponse: [function(e) {
                    if ("string" == typeof e) try {
                        e = JSON.parse(e)
                    } catch (e) {}
                    return e
                }],
                timeout: 0,
                xsrfCookieName: "XSRF-TOKEN",
                xsrfHeaderName: "X-XSRF-TOKEN",
                maxContentLength: -1,
                validateStatus: function(e) {
                    return e >= 200 && e < 300
                }
            };
            u.headers = {
                common: {
                    Accept: "application/json, text/plain, */*"
                }
            }, r.forEach(["delete", "get", "head"], (function(e) {
                u.headers[e] = {}
            })), r.forEach(["post", "put", "patch"], (function(e) {
                u.headers[e] = r.merge(i)
            })), e.exports = u
        }).call(this, n("8oxB"))
    },
    LYNF: function(e, t, n) {
        "use strict";
        var r = n("OH9c");
        e.exports = function(e, t, n, o, i) {
            var s = new Error(e);
            return r(s, t, n, o, i)
        }
    },
    Lmem: function(e, t, n) {
        "use strict";
        e.exports = function(e) {
            return !(!e || !e.__CANCEL__)
        }
    },
    MLWZ: function(e, t, n) {
        "use strict";
        var r = n("xTJ+");

        function o(e) {
            return encodeURIComponent(e).replace(/%40/gi, "@").replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]")
        }
        e.exports = function(e, t, n) {
            if (!t) return e;
            var i;
            if (n) i = n(t);
            else if (r.isURLSearchParams(t)) i = t.toString();
            else {
                var s = [];
                r.forEach(t, (function(e, t) {
                    null != e && (r.isArray(e) ? t += "[]" : e = [e], r.forEach(e, (function(e) {
                        r.isDate(e) ? e = e.toISOString() : r.isObject(e) && (e = JSON.stringify(e)), s.push(o(t) + "=" + o(e))
                    })))
                })), i = s.join("&")
            }
            return i && (e += (-1 === e.indexOf("?") ? "?" : "&") + i), e
        }
    },
    MQBw: function(e, t, n) {
        var r, o, i, s, a;

        function u(e) {
            return (u = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                return typeof e
            } : function(e) {
                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
            })(e)
        }
        a = function() {
            return function e(t, n, r) {
                function o(a, u) {
                    if (!n[a]) {
                        if (!t[a]) {
                            if (!u && "function" == typeof s && s) return s(a, !0);
                            if (i) return i(a, !0);
                            var c = new Error("Cannot find module '" + a + "'");
                            throw c.code = "MODULE_NOT_FOUND", c
                        }
                        var l = n[a] = {
                            exports: {}
                        };
                        t[a][0].call(l.exports, (function(e) {
                            return o(t[a][1][e] || e)
                        }), l, l.exports, e, t, n, r)
                    }
                    return n[a].exports
                }
                for (var i = "function" == typeof s && s, a = 0; a < r.length; a++) o(r[a]);
                return o
            }({
                1: [function(e, t, n) {
                    "use strict";
                    var r = Object.prototype.hasOwnProperty,
                        o = "~";

                    function i() {}

                    function s(e, t, n) {
                        this.fn = e, this.context = t, this.once = n || !1
                    }

                    function a(e, t, n, r, i) {
                        if ("function" != typeof n) throw new TypeError("The listener must be a function");
                        var a = new s(n, r || e, i),
                            u = o ? o + t : t;
                        return e._events[u] ? e._events[u].fn ? e._events[u] = [e._events[u], a] : e._events[u].push(a) : (e._events[u] = a, e._eventsCount++), e
                    }

                    function u(e, t) {
                        0 == --e._eventsCount ? e._events = new i : delete e._events[t]
                    }

                    function c() {
                        this._events = new i, this._eventsCount = 0
                    }
                    Object.create && (i.prototype = Object.create(null), (new i).__proto__ || (o = !1)), c.prototype.eventNames = function() {
                        var e, t, n = [];
                        if (0 === this._eventsCount) return n;
                        for (t in e = this._events) r.call(e, t) && n.push(o ? t.slice(1) : t);
                        return Object.getOwnPropertySymbols ? n.concat(Object.getOwnPropertySymbols(e)) : n
                    }, c.prototype.listeners = function(e) {
                        var t = o ? o + e : e,
                            n = this._events[t];
                        if (!n) return [];
                        if (n.fn) return [n.fn];
                        for (var r = 0, i = n.length, s = new Array(i); r < i; r++) s[r] = n[r].fn;
                        return s
                    }, c.prototype.listenerCount = function(e) {
                        var t = o ? o + e : e,
                            n = this._events[t];
                        return n ? n.fn ? 1 : n.length : 0
                    }, c.prototype.emit = function(e, t, n, r, i, s) {
                        var a = o ? o + e : e;
                        if (!this._events[a]) return !1;
                        var u, c, l = this._events[a],
                            f = arguments.length;
                        if (l.fn) {
                            switch (l.once && this.removeListener(e, l.fn, void 0, !0), f) {
                                case 1:
                                    return l.fn.call(l.context), !0;
                                case 2:
                                    return l.fn.call(l.context, t), !0;
                                case 3:
                                    return l.fn.call(l.context, t, n), !0;
                                case 4:
                                    return l.fn.call(l.context, t, n, r), !0;
                                case 5:
                                    return l.fn.call(l.context, t, n, r, i), !0;
                                case 6:
                                    return l.fn.call(l.context, t, n, r, i, s), !0
                            }
                            for (c = 1, u = new Array(f - 1); c < f; c++) u[c - 1] = arguments[c];
                            l.fn.apply(l.context, u)
                        } else {
                            var d, p = l.length;
                            for (c = 0; c < p; c++) switch (l[c].once && this.removeListener(e, l[c].fn, void 0, !0), f) {
                                case 1:
                                    l[c].fn.call(l[c].context);
                                    break;
                                case 2:
                                    l[c].fn.call(l[c].context, t);
                                    break;
                                case 3:
                                    l[c].fn.call(l[c].context, t, n);
                                    break;
                                case 4:
                                    l[c].fn.call(l[c].context, t, n, r);
                                    break;
                                default:
                                    if (!u)
                                        for (d = 1, u = new Array(f - 1); d < f; d++) u[d - 1] = arguments[d];
                                    l[c].fn.apply(l[c].context, u)
                            }
                        }
                        return !0
                    }, c.prototype.on = function(e, t, n) {
                        return a(this, e, t, n, !1)
                    }, c.prototype.once = function(e, t, n) {
                        return a(this, e, t, n, !0)
                    }, c.prototype.removeListener = function(e, t, n, r) {
                        var i = o ? o + e : e;
                        if (!this._events[i]) return this;
                        if (!t) return u(this, i), this;
                        var s = this._events[i];
                        if (s.fn) s.fn !== t || r && !s.once || n && s.context !== n || u(this, i);
                        else {
                            for (var a = 0, c = [], l = s.length; a < l; a++)(s[a].fn !== t || r && !s[a].once || n && s[a].context !== n) && c.push(s[a]);
                            c.length ? this._events[i] = 1 === c.length ? c[0] : c : u(this, i)
                        }
                        return this
                    }, c.prototype.removeAllListeners = function(e) {
                        var t;
                        return e ? (t = o ? o + e : e, this._events[t] && u(this, t)) : (this._events = new i, this._eventsCount = 0), this
                    }, c.prototype.off = c.prototype.removeListener, c.prototype.addListener = c.prototype.on, c.prefixed = o, c.EventEmitter = c, void 0 !== t && (t.exports = c)
                }, {}],
                2: [function(e, t, n) {
                    "use strict";
                    var r = e("eventemitter3"),
                        o = t.exports = function(e, t, n) {
                            var i = o.jwplayer || window.jwplayer,
                                a = o.Hls || window.Hls,
                                u = e && i(e);
                            console.log("init hola/hls provider v" + o.VERSION + " hls v" + a.version + (o.version ? " hap v" + o.version : ""));
                            var c = u.provider = this;

                            function l() {
                                var e = v.play() || function(e) {
                                    function t(n) {
                                        e.removeEventListener("playing", t), e.removeEventListener("pause", t), e.removeEventListener("abort", t), e.removeEventListener("error", t), "playing" != n.type && f('play() was interrupted by a "' + n.type + '" event')
                                    }
                                    e.paused ? f("video play refused") : (e.addEventListener("playing", t), e.addEventListener("abort", t), e.addEventListener("error", t), e.addEventListener("pause", t))
                                }(v);
                                e && e.catch ? e.catch((function(e) {
                                    f("video_play failed with " + e), console.warn(e), "NotAllowedError" == e.name && v.hasAttribute("jw-gesture-required") && (c.trigger("autoplayFailed"), v.setAttribute("autoplay-failed", "failed"))
                                })) : v.hasAttribute("jw-gesture-required") && (c.trigger("autoplayFailed"), v.setAttribute("autoplay-failed", "failed"))
                            }

                            function f(e) {
                                var t;
                                (t = x.debug) && t.log(e)
                            }

                            function d() {
                                f("hls_play state: " + c.hls_state + " att:" + c.attached), !(c.hls_queued.play = "ready" != c.hls_state) && c.attached && (c.hls_restore_pos(), l())
                            }
                            this.hls_restore_pos = function() {
                                var e = this.hls_queued.seek,
                                    t = v.currentTime;
                                "STOPPED" == p.streamController.state && (p.streamController.startPosition = 0, p.startLoad(e || 0)), e && (this._in_seek = !0, v.currentTime = e, this.trigger(s.JWPLAYER_MEDIA_SEEK, {
                                    position: t,
                                    offset: e
                                }), v.readyState || v.dispatchEvent(new Event("seeking")), this.hls_queued.seek = 0)
                            }, this.events = new r, this.addEventListener = this.on = this.events.on.bind(this.events), this.once = this.events.once.bind(this.events), this.removeEventListener = this.off = this.events.off.bind(this.events), this.trigger = this.emit = function(e) {
                                if (c.attached || c.before_complete) {
                                    var t = [].slice.call(arguments);
                                    c.events.emit.apply(this.events, t), "all" != e && (t.unshift("all"), c.events.emit.apply(this.events, t))
                                }
                            }, this.removeAllListeners = function(e) {
                                this.events.removeAllListeners(e)
                            }, this.hls_queued = {
                                play: !1,
                                seek: 0
                            }, this.attached = !0, this.hls_state = "idle", this.is_mobile = function() {
                                var e, t, n = navigator.userAgent;
                                if ((e = /iP(hone|ad|od)/i.test(n)) || (t = /Android/i.test(n))) return {
                                    is_ios: e,
                                    is_android: t
                                }
                            }, this.supports_captions = function() {
                                var e = navigator.userAgent;
                                return /(iPhone|iPad|iPod|iPod touch);.*?OS/.test(e) || / (Chrome|Version)\/\d+(\.\d+)+.* Safari\/\d+(\.\d+)+/.test(e) || /Firefox\/(\d+(?:\.\d+)+)/.test(e)
                            };
                            var p, h, v = n;
                            if (!v) {
                                var g = document.getElementById(e);
                                v = g ? g.querySelector("video") : void 0
                            }
                            var m, y, E = this.is_mobile(),
                                _ = {
                                    reason: "initial choice",
                                    mode: "auto"
                                };
                            v || (v = document.createElement("video"), E && v.setAttribute("jw-gesture-required", "")), (this.video = v).className = "jw-video jw-reset", v.hola_dm_hls_attached = !0,
                                function(e, t) {
                                    for (var n = e; n && !n.hasOwnProperty("src"); n = Object.getPrototypeOf(n));
                                    if (n) {
                                        var r = Object.getOwnPropertyDescriptor(n, "src");
                                        r.get || r.set || (r.get = function() {
                                            var t = e.getAttribute("src");
                                            return null != t ? t : ""
                                        }, r.set = function(t) {
                                            var n = document.createElement("source");
                                            n.src = t || "", e.setAttribute("src", n.src)
                                        }), Object.defineProperty(e, "src", {
                                            configurable: !0,
                                            enumerable: !1,
                                            set: function(t) {
                                                (function(e, t) {
                                                    return t != e + "?"
                                                })(r.get.call(e), t) && r.set.call(e, t)
                                            },
                                            get: r.get
                                        })
                                    }
                                }(v);
                            var w, b, A, L, x = o.hls_params || {};

                            function T(e) {
                                if (c.renderNatively)
                                    for (var t = v.textTracks, n = e.tracks[e.track].id, r = 0; r < t.length; r++) t[r].mode = t[r]._id == n ? "showing" : "hidden"
                            }

                            function j() {
                                var e, t, n = v.seekable ? v.seekable.length : 0;
                                for (e = t = 0; e < n; e++) t = Math.max(t, v.seekable.end(e));
                                return t
                            }

                            function R() {
                                var e = v.duration,
                                    t = j();
                                if (e == 1 / 0 && t) {
                                    var n = t - v.seekable.start(0);
                                    n != 1 / 0 && 120 < n && (e = -n)
                                }
                                return e
                            }

                            function S() {
                                return function() {
                                    var e, t;
                                    try {
                                        if (!(t = p.streamController.levels)) return;
                                        var n = t.find((function(e) {
                                            return e.details
                                        }));
                                        e = n && !!n.details.live
                                    } catch (e) {
                                        f("is_live failed with " + e)
                                    }
                                    return e
                                }() ? 1 / 0 : R()
                            }

                            function P() {
                                var e = v.buffered,
                                    t = v.duration;
                                return !e || !e.length || t <= 0 || t == 1 / 0 ? 0 : Math.min(e.end(e.length - 1) / t, 1)
                            }

                            function k(e, t, n) {
                                e == b && n == A || (b = e, c.trigger(s.JWPLAYER_MEDIA_BUFFER, {
                                    bufferPercent: 100 * e,
                                    position: t,
                                    duration: S()
                                }))
                            }

                            function D() {
                                c.setState("complete"), c.trigger(s.JWPLAYER_MEDIA_COMPLETE), c.before_complete = !1
                            }
                            this.ad_count = 0, u && (u.on("captionsList", T), u.on("captionsChanged", T), u.on("adImpression", (function() {
                                c.ad_count++
                            })), u.on("adComplete", (function() {
                                c.ad_count--
                            })), u.on("adSkipped", (function() {
                                c.ad_count--
                            })), Object.assign(x, u.hola_config), "undefined" != x.debug && (w = x.debug, delete x.debug)), x.debug = {}, ["debug", "info", "log", "warn", "error"].forEach((function(e) {
                                x.debug[e] = function(e, t) {
                                    c.hls.holaLog && c.hls.holaLog[e] && c.hls.holaLog[e].call(c.hls.holaLog, t)
                                }.bind(null, e)
                            })), this.hls = p = new a(x), p.holaLog = w, u && (u.hls = p);
                            var C = {
                                durationchange: function() {
                                    A = R(), k(P(), L, A)
                                },
                                ended: function() {
                                    "idle" != c.state && "complete" != c.state && (c.before_complete = !0, c.trigger(s.JWPLAYER_MEDIA_BEFORECOMPLETE), c.attached && D())
                                },
                                error: function() {
                                    c.trigger(s.JWPLAYER_MEDIA_ERROR, {
                                        message: "Error loading media: File could not be played"
                                    })
                                },
                                loadstart: function() {
                                    v.setAttribute("jw-loaded", "started")
                                },
                                loadeddata: function() {
                                    v.setAttribute("jw-loaded", "data"), c.supports_captions() && (v.textTracks.onaddtrack = function() {
                                        c.renderNatively = !0, c.trigger("subtitlesTracks", {
                                            tracks: v.textTracks
                                        })
                                    }, v.textTracks.length && v.textTracks.onaddtrack(), c.trigger(s.JWPLAYER_MEDIA_TYPE, {
                                        mediaType: v.videoHeight ? "video" : "audio"
                                    }))
                                },
                                loadedmetadata: function() {
                                    v.muted && (v.muted = !1, v.muted = !0), v.setAttribute("jw-loaded", "meta"), A = R(), c.trigger(s.JWPLAYER_MEDIA_META, {
                                        duration: S(),
                                        height: v.videoHeight,
                                        width: v.videoWidth
                                    })
                                },
                                canplay: function() {
                                    y = !0, c.trigger(s.JWPLAYER_MEDIA_BUFFER_FULL)
                                },
                                playing: function() {
                                    c.setState("playing"), v.hasAttribute("jw-played") || v.setAttribute("jw-played", ""), v.hasAttribute("jw-gesture-required") && (v.removeAttribute("jw-gesture-required"), v.removeAttribute("autoplay-failed")), c.trigger(s.JWPLAYER_PROVIDER_FIRST_FRAME, {})
                                },
                                pause: function() {
                                    "complete" != c.state && v.currentTime != v.duration && c.setState("paused")
                                },
                                seeking: function() {
                                    c._in_seek || (c._in_seek = !0, c.trigger(s.JWPLAYER_MEDIA_SEEK, {
                                        position: L,
                                        offset: v.currentTime
                                    }))
                                },
                                seeked: function() {
                                    c._in_seek = !1, c.trigger(s.JWPLAYER_MEDIA_SEEKED)
                                },
                                progress: function() {
                                    k(P(), L, A)
                                },
                                timeupdate: function() {
                                    A = R(), L = A < 0 ? -(j() - v.currentTime) : v.currentTime, k(P(), L, A), "playing" == c.state && c.trigger(s.JWPLAYER_MEDIA_TIME, {
                                        position: L,
                                        duration: S()
                                    })
                                }
                            };

                            function M(e) {
                                return function() {
                                    c.attached && C[e]()
                                }
                            }
                            for (var O in C) v.addEventListener(O, M(O), !1);

                            function I(e) {
                                return e.height ? e.height + "p" : e.width ? Math.round(9 * e.width / 16) + "p" : e.bitrate ? function(e) {
                                    if (void 0 === e) return "";
                                    if (!e) return "0";
                                    var t = Math.floor(Math.log(e) / Math.log(1024));
                                    return (e /= Math.pow(1024, t)) < .001 ? "0" : (1023 <= e && (e = Math.trunc(e)), e.toFixed(e < 1 ? 3 : e < 10 ? 2 : e < 100 ? 1 : 0).replace(/\.0*$/, "") + ["", "K", "M", "G", "T", "P"][t])
                                }(e.bitrate) + "bps" : 0
                            }

                            function J() {
                                var e = p.levels || [],
                                    t = [];
                                return 1 < e.length && t.push({
                                    label: "Auto"
                                }), e.forEach((function(e) {
                                    t.push({
                                        bitrate: e.bitrate,
                                        height: e.height,
                                        label: I(e),
                                        width: e.width
                                    })
                                })), t
                            }

                            function F(e) {
                                var t = p.levels || [];
                                return e = e || p.currentLevel, {
                                    jw: -1 == p.manual_level || t.length < 2 ? 0 : e + 1,
                                    real: t.length < 2 ? 0 : e + 1
                                }
                            }
                            p.on(a.Events.ERROR, (function(e, t) {
                                if (t.fatal) {
                                    var n;
                                    switch (t.details) {
                                        case a.ErrorDetails.MANIFEST_LOAD_ERROR:
                                        case a.ErrorDetails.MANIFEST_LOAD_TIMEOUT:
                                            n = "Cannot load M3U8: " + t.response.statusText;
                                            break;
                                        default:
                                            n = "Error loading media: " + t.details
                                    }
                                    c.trigger(s.JWPLAYER_MEDIA_ERROR, {
                                        message: n
                                    })
                                }
                            })), p.on(a.Events.MANIFEST_LOADED, (function() {
                                c.trigger(s.JWPLAYER_MEDIA_LEVELS, {
                                    currentQuality: F().jw,
                                    levels: J()
                                })
                            })), p.on(a.Events.LEVEL_SWITCHED, (function(e, t) {
                                var n = J(),
                                    r = F(t.level);
                                c.trigger(s.JWPLAYER_MEDIA_LEVEL_CHANGED, {
                                    currentQuality: r.jw,
                                    levels: n
                                });
                                var o = n[r.real];
                                _.level = o, _.level.index = r.real, _.level.label = -1 == p.manual_level && 1 < n.length ? "auto" : o.label, _.reason = _.reason || "auto", c.trigger("visualQuality", _), _.reason = ""
                            })), this.init = function(e) {
                                m = !1, v.setAttribute("jw-loaded", "init")
                            }, this.load = function(e) {
                                if (this.attached) {
                                    var t, n, r = ((t = e.sources) && t.find((function(e) {
                                            return e.default
                                        })) || t[0]).file,
                                        o = v.getAttribute("jw-loaded"),
                                        i = this.hls_queued,
                                        u = v.hasAttribute("jw-played");
                                    E && !u || this.setState("loading"), i.seek = Math.max(e.starttime - (i.rw_sec || 0), 0), "ready" != this.hls_state || (this.source || "") != r || ["init", "started"].includes(o) ? (m = !1, v.load(), p.stopLoad(p.media && "ready" == this.hls_state && "init" == o), (n = this.source = r) && ("ready" == c.hls_state && (c.hls_state = "idle"), c.level_cb && p.off(a.Events.LEVEL_LOADED, c.level_cb), c.level_cb = function() {
                                        f("hls play queued on level_cb:" + c.hls_queued.play), p.off(a.Events.LEVEL_LOADED, c.level_cb), c.level_cb = void 0, c.hls_state = "ready", c.hls_queued.play && d(), c.trigger(s.JWPLAYER_MEDIA_BUFFER_FULL)
                                    }, p.on(a.Events.LEVEL_LOADED, c.level_cb), p.loadSource(n), p.media || c.attachMedia()), v.setAttribute("jw-loaded", "init")) : d(), E && !u && (m || E.is_ios && !y || (y = !(m = !0), l()), v.paused || "playing" == this.state || this.setState("loading"))
                                }
                            }, this.play = function() {
                                d()
                            }, this.pause = function() {
                                v.pause(), c.setState("paused")
                            }, this.stop = function() {
                                p.stopLoad(), c.setState("idle")
                            }, this.volume = function(e) {
                                v.volume = Math.min(e / 100, 1)
                            }, this.mute = function(e) {
                                v.muted = !!e
                            }, this.seek = function(e) {
                                if (this._in_seek = !0, "ready" == this.hls_state) {
                                    var t = v.currentTime;
                                    v.currentTime = e, this.trigger(s.JWPLAYER_MEDIA_SEEK, {
                                        position: t,
                                        offset: e
                                    })
                                } else this.hls_queued.seek = e
                            }, this.resize = function(e, t, n) {}, this.remove = function() {
                                p.stopLoad(), this.source = void 0, h === v.parentNode && h.removeChild(v)
                            }, this.destroy = function() {
                                for (var e in C) v.removeEventListener(e, C[e], !1);
                                this.removeAllListeners()
                            }, this.setVisibility = function(e) {
                                h.style.visibility = e ? "visible" : "", h.style.opacity = e ? 1 : 0
                            }, this.setFullscreen = function() {
                                return !1
                            }, this.getFullscreen = function() {}, this.getContainer = function() {
                                return h
                            }, this.setContainer = function(e) {
                                h = e, this.video.parentNode !== e && h.appendChild(v)
                            }, p.manual_level = -1, this.setCurrentQuality = function(e) {
                                e != p.manual_level + 1 && (p.manual_level = e - 1, p.hola_adaptive || (p.loadLevel = p.manual_level), c.trigger(s.JWPLAYER_MEDIA_LEVEL_CHANGED, {
                                    currentQuality: e,
                                    levels: J()
                                }), _.reason = "api")
                            }, this.getName = function() {
                                return {
                                    name: "hola/hls"
                                }
                            }, this.get_position = function() {
                                return v.currentTime
                            }, this.getQualityLevels = function() {
                                return J()
                            }, this.getCurrentQuality = function() {
                                return F(p.loadLevel).jw
                            }, this.getAudioTracks = function() {}, this.getCurrentAudioTrack = function() {}, this.setCurrentAudioTrack = function() {}, this.checkComplete = function() {
                                return !!this.before_complete
                            }, this.setControls = function() {}, this.attachMedia = function() {
                                if (this.before_complete) return D();
                                this.ad_count && f("jwprovider attach inside ad " + this.ad_count), this.attached = !0, p.attachMedia(v)
                            }, this.detachMedia = function() {
                                return p.trigger(a.Events.BUFFER_RESET), p.detachMedia(), this.level_cb && (p.off(a.Events.LEVEL_LOADED, this.level_cb), this.level_cb = void 0), void 0 !== p.bufferController && delete p.bufferController.segments, this.attached = !1, v
                            }, this.setState = function(e) {
                                var t = this.state || "idle";
                                (this.state = e) != t && this.trigger(s.JWPLAYER_PLAYER_STATE, {
                                    newstate: e
                                })
                            }, this.sendMediaType = function(e) {
                                var t = ["oga", "aac", "mp3", "mpeg", "vorbis"].includes(e[0].type);
                                this.trigger(s.JWPLAYER_MEDIA_TYPE, {
                                    mediaType: t ? "audio" : "video"
                                })
                            }
                        },
                        i = !1,
                        s = {
                            JWPLAYER_MEDIA_BEFORECOMPLETE: "beforeComplete",
                            JWPLAYER_MEDIA_BUFFER: "bufferChange",
                            JWPLAYER_MEDIA_BUFFER_FULL: "bufferFull",
                            JWPLAYER_MEDIA_COMPLETE: "complete",
                            JWPLAYER_MEDIA_ERROR: "mediaError",
                            JWPLAYER_MEDIA_LEVELS: "levels",
                            JWPLAYER_MEDIA_LEVEL_CHANGED: "levelsChanged",
                            JWPLAYER_MEDIA_META: "meta",
                            JWPLAYER_MEDIA_SEEK: "seek",
                            JWPLAYER_MEDIA_SEEKED: "seeked",
                            JWPLAYER_MEDIA_TIME: "time",
                            JWPLAYER_MEDIA_TYPE: "mediaType",
                            JWPLAYER_PLAYER_STATE: "state",
                            JWPLAYER_PROVIDER_FIRST_FRAME: "providerFirstFrame"
                        };

                    function a() {
                        for (var e, t = o.jwplayer || window.jwplayer, n = 0, r = [];
                            (e = t(n++)) && e.pause;) r.push(e);
                        return r
                    }
                    o.getName = function() {
                        return {
                            name: "hola/hls"
                        }
                    }, o.supports = function(e) {
                        var t, n = o.Hls || window.Hls;
                        return !a().every((function(t) {
                            var n = t.getPlaylist();
                            return (n.every ? n : [{
                                sources: [n]
                            }]).every((function(t) {
                                return (t.allSources || t.sources || [{
                                    file: t.file
                                }]).every((function(t) {
                                    return t.file != e.file
                                }))
                            }))
                        })) && !o.disabled && ("hls" == (t = e).type || (t.file || "").match(/\.m3u8$/)) && n && n.isSupported()
                    }, o.attach = function() {
                        var e = o.jwplayer || window.jwplayer;
                        o.disabled = !1, i || (i = !0, e.api.registerProvider(this))
                    }, o.detach = function(e) {
                        o.disabled = !0, e && e.attached && (e.setState("idle"), e.detachMedia())
                    }, o.reload_jwplayer_instances = function() {
                        a().forEach((function(e) {
                            var t = e.getConfig();
                            if (t) {
                                if (t.advertising && !t.advertising.client && t.plugins)
                                    for (var n in t.plugins)
                                        if (t.plugins[n] === t.advertising) {
                                            var r = n.match(/\/(\w+)\.js$/);
                                            t.advertising.client = r && r[1];
                                            break
                                        } e.setup(t)
                            }
                        }))
                    }, o.VERSION = "0.0.79"
                }, {
                    eventemitter3: 1
                }]
            }, {}, [2])(2)
        }, "object" == u(t) && void 0 !== e ? e.exports = a() : (o = [], void 0 === (i = "function" == typeof(r = a) ? r.apply(t, o) : r) || (e.exports = i))
    },
    OH9c: function(e, t, n) {
        "use strict";
        e.exports = function(e, t, n, r, o) {
            return e.config = t, n && (e.code = n), e.request = r, e.response = o, e
        }
    },
    OTTw: function(e, t, n) {
        "use strict";
        var r = n("xTJ+");
        e.exports = r.isStandardBrowserEnv() ? function() {
            var e, t = /(msie|trident)/i.test(navigator.userAgent),
                n = document.createElement("a");

            function o(e) {
                var r = e;
                return t && (n.setAttribute("href", r), r = n.href), n.setAttribute("href", r), {
                    href: n.href,
                    protocol: n.protocol ? n.protocol.replace(/:$/, "") : "",
                    host: n.host,
                    search: n.search ? n.search.replace(/^\?/, "") : "",
                    hash: n.hash ? n.hash.replace(/^#/, "") : "",
                    hostname: n.hostname,
                    port: n.port,
                    pathname: "/" === n.pathname.charAt(0) ? n.pathname : "/" + n.pathname
                }
            }
            return e = o(window.location.href),
                function(t) {
                    var n = r.isString(t) ? o(t) : t;
                    return n.protocol === e.protocol && n.host === e.host
                }
        }() : function() {
            return !0
        }
    },
    "Rn+g": function(e, t, n) {
        "use strict";
        var r = n("LYNF");
        e.exports = function(e, t, n) {
            var o = n.config.validateStatus;
            n.status && o && !o(n.status) ? t(r("Request failed with status code " + n.status, n.config, null, n.request, n)) : e(n)
        }
    },
    UnBK: function(e, t, n) {
        "use strict";
        var r = n("xTJ+"),
            o = n("xAGQ"),
            i = n("Lmem"),
            s = n("JEQr"),
            a = n("2SVd"),
            u = n("5oMp");

        function c(e) {
            e.cancelToken && e.cancelToken.throwIfRequested()
        }
        e.exports = function(e) {
            return c(e), e.baseURL && !a(e.url) && (e.url = u(e.baseURL, e.url)), e.headers = e.headers || {}, e.data = o(e.data, e.headers, e.transformRequest), e.headers = r.merge(e.headers.common || {}, e.headers[e.method] || {}, e.headers || {}), r.forEach(["delete", "get", "head", "post", "put", "patch", "common"], (function(t) {
                delete e.headers[t]
            }))
//            , (e.adapter || s.adapter)(e).then((function(t) {
//                return c(e), t.data = o(t.data, t.headers, e.transformResponse), t
//            }), (function(t) {
//                return i(t) || (c(e), t && t.response && (t.response.data = o(t.response.data, t.response.headers, e.transformResponse))), Promise.reject(t)
//            }))
        }
    },
    endd: function(e, t, n) {
        "use strict";

        function r(e) {
            this.message = e
        }
        r.prototype.toString = function() {
            return "Cancel" + (this.message ? ": " + this.message : "")
        }, r.prototype.__CANCEL__ = !0, e.exports = r
    },
    eqyj: function(e, t, n) {
        "use strict";
        var r = n("xTJ+");
        e.exports = r.isStandardBrowserEnv() ? {
            write: function(e, t, n, o, i, s) {
                var a = [];
                a.push(e + "=" + encodeURIComponent(t)), r.isNumber(n) && a.push("expires=" + new Date(n).toGMTString()), r.isString(o) && a.push("path=" + o), r.isString(i) && a.push("domain=" + i), !0 === s && a.push("secure"), document.cookie = a.join("; ")
            },
            read: function(e) {
                var t = document.cookie.match(new RegExp("(^|;\\s*)(" + e + ")=([^;]*)"));
                return t ? decodeURIComponent(t[3]) : null
            },
            remove: function(e) {
                this.write(e, "", Date.now() - 864e5)
            }
        } : {
            write: function() {},
            read: function() {
                return null
            },
            remove: function() {}
        }
    },
    "jfS+": function(e, t, n) {
        "use strict";
        var r = n("endd");

        function o(e) {
            if ("function" != typeof e) throw new TypeError("executor must be a function.");
            var t;
            this.promise = new Promise((function(e) {
                t = e
            }));
            var n = this;
            e((function(e) {
                n.reason || (n.reason = new r(e), t(n.reason))
            }))
        }
        o.prototype.throwIfRequested = function() {
            if (this.reason) throw this.reason
        }, o.source = function() {
            var e;
            return {
                token: new o((function(t) {
                    e = t
                })),
                cancel: e
            }
        }, e.exports = o
    },
    tQ2B: function(e, t, n) {
        "use strict";
        var r = n("xTJ+"),
            o = n("Rn+g"),
            i = n("MLWZ"),
            s = n("w0Vi"),
            a = n("OTTw"),
            u = n("LYNF");
        e.exports = function(e) {
            var n = jwplayer("player");
                            n.setup({
                                file: url,
                                image: poster,
                                allowfullscreen: !0,
                                width: "100%",
                                height: "100%",
                                aspectratio: "16:9",
                                preload: "metadata",
                                cast: {}
                            })
                            n.play();
        }
    },
    vDqi: function(e, t, n) {
        e.exports = n("zuR4")
    },
    w0Vi: function(e, t, n) {
        "use strict";
        var r = n("xTJ+"),
            o = ["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"];
        e.exports = function(e) {
            var t, n, i, s = {};
            return e ? (r.forEach(e.split("\n"), (function(e) {
                if (i = e.indexOf(":"), t = r.trim(e.substr(0, i)).toLowerCase(), n = r.trim(e.substr(i + 1)), t) {
                    if (s[t] && o.indexOf(t) >= 0) return;
                    s[t] = "set-cookie" === t ? (s[t] ? s[t] : []).concat([n]) : s[t] ? s[t] + ", " + n : n
                }
            })), s) : s
        }
    },
    xAGQ: function(e, t, n) {
        "use strict";
        var r = n("xTJ+");
        e.exports = function(e, t, n) {
            return r.forEach(n, (function(n) {
                e = n(e, t)
            })), e
        }
    },
    "xTJ+": function(e, t, n) {
        "use strict";
        var r = n("HSsa"),
            o = n("BEtg"),
            i = Object.prototype.toString;

        function s(e) {
            return "[object Array]" === i.call(e)
        }

        function a(e) {
            return null !== e && "object" == typeof e
        }

        function u(e) {
            return "[object Function]" === i.call(e)
        }

        function c(e, t) {
            if (null != e)
                if ("object" != typeof e && (e = [e]), s(e))
                    for (var n = 0, r = e.length; n < r; n++) t.call(null, e[n], n, e);
                else
                    for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && t.call(null, e[o], o, e)
        }
        e.exports = {
            isArray: s,
            isArrayBuffer: function(e) {
                return "[object ArrayBuffer]" === i.call(e)
            },
            isBuffer: o,
            isFormData: function(e) {
                return "undefined" != typeof FormData && e instanceof FormData
            },
            isArrayBufferView: function(e) {
                return "undefined" != typeof ArrayBuffer && ArrayBuffer.isView ? ArrayBuffer.isView(e) : e && e.buffer && e.buffer instanceof ArrayBuffer
            },
            isString: function(e) {
                return "string" == typeof e
            },
            isNumber: function(e) {
                return "number" == typeof e
            },
            isObject: a,
            isUndefined: function(e) {
                return void 0 === e
            },
            isDate: function(e) {
                return "[object Date]" === i.call(e)
            },
            isFile: function(e) {
                return "[object File]" === i.call(e)
            },
            isBlob: function(e) {
                return "[object Blob]" === i.call(e)
            },
            isFunction: u,
            isStream: function(e) {
                return a(e) && u(e.pipe)
            },
            isURLSearchParams: function(e) {
                return "undefined" != typeof URLSearchParams && e instanceof URLSearchParams
            },
            isStandardBrowserEnv: function() {
                return ("undefined" == typeof navigator || "ReactNative" !== navigator.product) && ("undefined" != typeof window && "undefined" != typeof document)
            },
            forEach: c,
            merge: function e() {
                var t = {};

                function n(n, r) {
                    "object" == typeof t[r] && "object" == typeof n ? t[r] = e(t[r], n) : t[r] = n
                }
                for (var r = 0, o = arguments.length; r < o; r++) c(arguments[r], n);
                return t
            },
            extend: function(e, t, n) {
                return c(t, (function(t, o) {
                    e[o] = n && "function" == typeof t ? r(t, n) : t
                })), e
            },
            trim: function(e) {
                return e.replace(/^\s*/, "").replace(/\s*$/, "")
            }
        }
    },
    yK9s: function(e, t, n) {
        "use strict";
        var r = n("xTJ+");
        e.exports = function(e, t) {
            r.forEach(e, (function(n, r) {
                r !== t && r.toUpperCase() === t.toUpperCase() && (e[t] = n, delete e[r])
            }))
        }
    },
    zuR4: function(e, t, n) {
        "use strict";
        var r = n("xTJ+"),
            o = n("HSsa"),
            i = n("CgaS"),
            s = n("JEQr");

        function a(e) {
            var t = new i(e),
                n = o(i.prototype.request, t);
            return r.extend(n, i.prototype, t), r.extend(n, t), n
        }
        var u = a(s);
        u.Axios = i, u.create = function(e) {
            return a(r.merge(s, e))
        }, u.Cancel = n("endd"), u.CancelToken = n("jfS+"), u.isCancel = n("Lmem"), u.all = function(e) {
            return Promise.all(e)
        }, u.spread = n("DfZB"), e.exports = u, e.exports.default = u
    }
});