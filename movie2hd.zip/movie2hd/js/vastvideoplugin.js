function AdSlot(_name, _type, _time, _zone) {
    this.name = _name;
    this.type = _type;
    this.time = _time;
    this.zone = _zone;
    this.source = "";
    this.seen = false;
    this.playOnce = true;
}



function convertTimeFormat(hhmmss) {
    var _time = hhmmss.substr(0, 1) * 3600 + hhmmss.substr(3, 2) * 60 + hhmmss.substr(6, 2) * 1;
    return _time
}

function constructAdList(responseObj) {
    for (v in AdList) {
        if (AdList[v].type.indexOf("roll") + 1) {
            var adElement = responseObj.getElementById(AdList[v].name);
            MediaFiles = adElement.getElementsByTagName("MediaFiles");
            URL = MediaFiles[0].getElementsByTagName("URL");
            if (URL[0] == undefined) {
                URL = MediaFiles[0].getElementsByTagName("MediaFile");
            }
            AdList[v].source = URL[0].childNodes[0].data;
        }
    }
    videoTag.addEventListener('timeupdate', showAdSlots, false);
}


// Loading ads data from defined server
AdsRequest = function(AdObj, cc) {

    var http_request = new XMLHttpRequest();
    var script = "bannerTypeHtml:vastInlineBannerTypeHtml:vastInlineHtml";

    //constructing list for further populating and sorting

    var i1 = 0;
    var i2 = 0;
    var i3 = 0;
    var i4 = 0;
    var zones = "";
    for (v in AdObj.schedule) {
        switch (AdObj.schedule[v].position) {
            case "pre-roll":
                var a = new AdSlot("pre-roll-" + i1, "pre-roll", 0, AdObj.schedule[v].zone);
                i1++;
                AdList.push(a);

                break
            case "mid-roll":
                var a = new AdSlot("mid-roll-" + i2, "mid-roll", convertTimeFormat(AdObj.schedule[v].startTime), AdObj.schedule[v].zone);
                i2++;
                AdList.push(a);
                break
            case "post-roll":
                var a = new AdSlot("post-roll-" + i3, "post-roll", 0, AdObj.schedule[v].zone);
                i3++;
                AdList.push(a);
                break
            case "auto:bottom":
                var a = new AdSlot("auto:bottom-" + i4, "auto:bottom", convertTimeFormat(AdObj.schedule[v].startTime), AdObj.schedule[v].zone);
                i4++;
                AdList.push(a);
                break
            default:
                break
        }
    }
    videoTag.addEventListener("canplay", setPostRollTime, false);
    videoTag.load();

    for (v in AdList) {
        zones += AdList[v].name + "=" + AdList[v].zone + "|";
    }
    zones = zones.substr(0, zones.length - 1)
    console.log(zones);

    var nz = "1";
    var format = "vast";
    var charset = "UTF-8";
    var params = "script=" + script + "&zones=" + encodeURIComponent(zones) + "&nz=" + nz + "&format=" + format + "&charset=" + charset;

    http_request.open("GET", AdObj.servers[0]["apiAddress" + cc], true);
    http_request.send(null);
    http_request.onreadystatechange = function() {
        if (http_request.readyState == 4) {
            if (http_request.status == 200) {
                var xml = http_request.responseXML;
                constructAdList(xml);
            }
            http_request = null;
        }
    }

};



function showSlot(slot) {
    if ($("#videoads1").val() && moment($('#videoads1-exp').val()).isAfter(moment().format('MM/DD/YYYY'))) {
        $(".skipBtn").show().addClass("disabled");
        videoTag.src = $("#videoads1").val();
        videoTag.play();
        var intervalAd = setInterval(function() {
            if ($('#example_video_1').get(0).currentTime > 1) {
                $(".regisBtn").removeClass("disabled");
                $(".regisBtn").attr("href", $("#videoads1-link").val());

            }
            if ($('#example_video_1').get(0).currentTime > $("#timeskip").val()) {
                $(".skipBtn").removeClass("disabled");
                $(".skipBtn").click(function() {
                    if ($("#videoads2").val()) {
                        showSlot2();
                    } else {
                        resumePlayBackAfterSlotShow();
                    }
                });
                clearInterval(intervalAd);
            }
        }, 100);
        // console.log(slot);
        if ($("#videoads2").val()) {
            videoTag.addEventListener('ended', showSlot2, false);
        } else {
            videoTag.addEventListener('ended', resumePlayBackAfterSlotShow, false);
        }

    } else {
        if ($("#videoads2").val()) {
            showSlot2();
        } else {
            videoTag.addEventListener('ended', resumePlayBackAfterSlotShow, false);
        }
    }
}

function showSlot2() {
    if ($("#videoads2").val() && moment($('#videoads2-exp').val()).isAfter(moment().format('MM/DD/YYYY'))) {
        $(".skipBtn").show().addClass("disabled");
        videoTag.src = $("#videoads2").val();
        videoTag.play();
        var intervalAd = setInterval(function() {
            if ($('#example_video_1').get(0).currentTime > 1) {
                $(".regisBtn").removeClass("disabled");
                $(".regisBtn").attr("href", $("#videoads2-link").val());

            }
            if ($('#example_video_1').get(0).currentTime > $("#timeskip").val()) {
                $(".skipBtn").removeClass("disabled");
                $(".skipBtn").click(function() {
                    if ($("#videoads3").val()) {
                        showSlot3();
                    } else {
                        resumePlayBackAfterSlotShow();
                    }
                });
                clearInterval(intervalAd);
            }
        }, 100);
        // console.log(slot);
        if ($("#videoads3").val()) {
            videoTag.addEventListener('ended', showSlot3, false);
        } else {
            videoTag.addEventListener('ended', resumePlayBackAfterSlotShow, false);
        }

    } else {
        if ($("#videoads3").val()) {
            showSlot3();
        } else {
            videoTag.addEventListener('ended', resumePlayBackAfterSlotShow, false);
        }
    }

}

function showSlot3() {
    if ($("#videoads3").val() && moment($('#videoads3-exp').val()).isAfter(moment().format('MM/DD/YYYY'))) {
        $(".skipBtn").show().addClass("disabled");
        videoTag.src = $("#videoads3").val();
        videoTag.play();
        var intervalAd = setInterval(function() {
            if ($('#example_video_1').get(0).currentTime > 1) {
                $(".regisBtn").removeClass("disabled");
                $(".regisBtn").attr("href", $("#videoads3-link").val());

            }
            if ($('#example_video_1').get(0).currentTime > $("#timeskip").val()) {
                $(".skipBtn").removeClass("disabled");
                $(".skipBtn").click(function() {
                    if ($("#videoads4").val()) {
                        showSlot4();
                    } else {
                        resumePlayBackAfterSlotShow();
                    }
                });
                clearInterval(intervalAd);
            }
        }, 100);
        // console.log(slot);
        if ($("#videoads4").val()) {
            videoTag.addEventListener('ended', showSlot4, false);
        } else {
            videoTag.addEventListener('ended', resumePlayBackAfterSlotShow, false);
        }

    } else {
        if ($("#videoads4").val()) {
            showSlot4();
        } else {
            videoTag.addEventListener('ended', resumePlayBackAfterSlotShow, false);
        }
    }
}

function showSlot4() {
    if ($("#videoads4").val() && moment($('#videoads4-exp').val()).isAfter(moment().format('MM/DD/YYYY'))) {
        $(".skipBtn").show().addClass("disabled");
        videoTag.src = $("#videoads4").val();
        videoTag.play();
        var intervalAd = setInterval(function() {
            if ($('#example_video_1').get(0).currentTime > 1) {
                $(".regisBtn").removeClass("disabled");
                $(".regisBtn").attr("href", $("#videoads4-link").val());

            }
            if ($('#example_video_1').get(0).currentTime > $("#timeskip").val()) {
                $(".skipBtn").removeClass("disabled");
                $(".skipBtn").click(function() {

                    resumePlayBackAfterSlotShow();

                });
                clearInterval(intervalAd);
            }
        }, 100);
        // console.log(slot);

        videoTag.addEventListener('ended', resumePlayBackAfterSlotShow, false);


    } else {

        videoTag.addEventListener('ended', resumePlayBackAfterSlotShow, false);

    }

}


function initAdsFor(videoID) {
    window.tempTime = 0;

    window.counterOfStreams = 0;
    window.videoTag = document.getElementById(videoID);
    videoTag.mainTrack = videoTag.src;
    window.AdList = new Array;


    window.AdObj = parseAdsParameters(videoTag.getAttribute('ads'));
    window.AdObj2 = parseAdsParameters(videoTag.getAttribute('ads2'));
    window.AdObj3 = parseAdsParameters(videoTag.getAttribute('ads3'));
    window.AdObj4 = parseAdsParameters(videoTag.getAttribute('ads4'));

    window.AdsRequest(AdObj, 1);
    // window.AdsRequest(AdObj2, 2);
    // window.AdsRequest(AdObj2);
    // window.AdsRequest(AdObj3);
    // window.AdsRequest(AdObj4);

}
//Parsing parameters from video tag
parseAdsParameters = function(input) {
    var AdObj = !(/[^,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t]/.test(input.replace(/"(\\.|[^"\\])*"/g, ''))) && eval('(' + input + ')');
    return AdObj;
}

function enforcePrecision(n, nDecimalDigits) {
    return +(n).toFixed(nDecimalDigits);
}

function seekToOriginalPoint() {
    videoTag.removeEventListener('canplaythrough', seekToOriginalPoint, false);
    videoTag.removeEventListener('load', seekToOriginalPoint, false);
    videoTag.currentTime = enforcePrecision(tempTime, 1);
    videoTag.play();
    videoTag.addEventListener('timeupdate', showAdSlots, false);
}

function resumePlayBackAfterSlotShow() {
    videoTag.removeEventListener('ended', resumePlayBackAfterSlotShow, false);
    $(".skipBtn").hide();
    $(".regisBtn").hide();
    videoTag.src = videoTag.mainTrack;
    videoTag.play();

    if (videoTag.readyState !== 4) { //HAVE_ENOUGH_DATA
        videoTag.addEventListener('canplaythrough', seekToOriginalPoint, false);
        videoTag.addEventListener('load', seekToOriginalPoint, false); //add load event as well to avoid errors, sometimes 'canplaythrough' won't dispatch.
        videoTag.pause();
    }
}


function slotForCurrentTime(currentTime) {
    for (v in AdList) {
        if (!AdList[v].seen) {
            if (AdList[v].time == currentTime) {
                return AdList[v];
            }
        }
    }
    return null;

}

function showAdSlots() {

    var slot = slotForCurrentTime(Math.floor(videoTag.currentTime));
    if (slot) {
        slot.seen = true;
        tempTime = videoTag.currentTime;
        videoTag.removeEventListener('timeupdate', showAdSlots, false);
        showSlot(slot);


    }

}

function setPostRollTime() {
    videoTag.removeEventListener("canplay", setPostRollTime, false);
    for (v in AdList) {
        if (AdList[v].type == "post-roll") {
            AdList[v].time = Math.floor(videoTag.duration);
        }
    }
}