<?php get_header() ?>
<?php global $redux_demo; ?>
        <div class="container">
            <div class="content">
<?php
    $template = locate_template('banner/a.php');
    if ($template) {
        load_template($template);
    }
    ?>

                <div class="content-movie">
                     <?php 

                    $template = locate_template('sidebar/left-sidebar.php');

                        if( $template ){
                            load_template( $template );        
                        }
                    ?>
                <div class="contentmovie">
                                <?php
                    // Start the loop.
                    while ( have_posts() ) : the_post(); ?>
                     
                    <div class="movietext">
                        <h1><?php echo the_title() ?></h1>
                    </div>
                    <div class="movie">
                  
                        <div class="content-col" style="min-height: 500px">
                        <?php echo the_content() ?>
                           
                        </div>
                        <?php endwhile; ?>
                    </div>
                    <?php 
           
           $template = locate_template('banner/a5-7.php');
   
                   if( $template ){
                       load_template( $template );        
                   }
           ?>
                  <?php
        $template = locate_template('banner/a10-12.php');
        if ($template) {
            load_template($template);
        }
        ?>
                </div>
                </section>
                <?php 
                            
                            $template = locate_template('sidebar/right-sidebar.php');
                    
                                    if( $template ){
                                        load_template( $template );        
                                    }
                            ?>
                </div>
            </div>
        </div>
        <?php 
                            
                            $template = locate_template('banner/c.php');
                    
                                    if( $template ){
                                        load_template( $template );        
                                    }
                            ?>

     <?php get_footer() ?>