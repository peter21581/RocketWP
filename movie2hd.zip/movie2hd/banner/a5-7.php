<?php global $redux_demo; ?>
                            <div class="adcen">
                                
                              <?php if($redux_demo['opt-media-adsa5']['url']) { ?>
                                <div class="adb">
                                    <div class="widgettitle-banner">A5</div>
                                    <?php if($redux_demo['opt-rel-adsa5'] == 1) { ?>
                                    <a id="a5" href="<?php echo $redux_demo['opt-media-adsa5-link'] ?>"  rel="dofollow" target="_blank">
                                <?php } else { ?>
                                    <a id="a5" href="<?php echo $redux_demo['opt-media-adsa5-link'] ?>"  rel="nofollow" target="_blank">
                                <?php } ?>
                                    <img width="773" height="130" src="<?php echo $redux_demo['opt-media-adsa5']['url'] ?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="A5" />
                                  </a>
                                </div>
                                  <?php } ?>
                                    <?php if($redux_demo['opt-media-adsa6']['url']) { ?>
                                <div class="adb">
                                    <div class="widgettitle-banner">A6</div>
                                    <?php if($redux_demo['opt-rel-adsa6'] == 1) { ?>
                                    <a id="a6" href="<?php echo $redux_demo['opt-media-adsa6-link'] ?>"  rel="dofollow" target="_blank">
                                <?php } else { ?>
                                    <a id="a6" href="<?php echo $redux_demo['opt-media-adsa6-link'] ?>"  rel="nofollow" target="_blank">
                                <?php } ?>
                                    <img width="773" height="130" src="<?php echo $redux_demo['opt-media-adsa6']['url'] ?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="A6" />
                                  </a>
                                </div>
                                  <?php } ?>
                                    <?php if($redux_demo['opt-media-adsa7']['url']) { ?>
                                <div class="adb">
                                    <div class="widgettitle-banner">A7</div>
                                    <?php if($redux_demo['opt-rel-adsa7'] == 1) { ?>
                                    <a id="a7" href="<?php echo $redux_demo['opt-media-adsa7-link'] ?>"  rel="dofollow" target="_blank">
                                <?php } else { ?>
                                    <a id="a7" href="<?php echo $redux_demo['opt-media-adsa7-link'] ?>"  rel="nofollow" target="_blank">
                                <?php } ?>
                                    <img width="773" height="130" src="<?php echo $redux_demo['opt-media-adsa7']['url'] ?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="A7" />
                                  </a>
                                </div>
                                  <?php } ?>
                                    <?php if($redux_demo['opt-media-adsa8']['url']) { ?>
                                <div class="adb">
                                    <div class="widgettitle-banner">A8</div>
                                    <?php if($redux_demo['opt-rel-adsa8'] == 1) { ?>
                                    <a id="a8" href="<?php echo $redux_demo['opt-media-adsa8-link'] ?>"  rel="dofollow" target="_blank">
                                <?php } else { ?>
                                    <a id="a8" href="<?php echo $redux_demo['opt-media-adsa8-link'] ?>"  rel="nofollow" target="_blank">
                                <?php } ?>
                                    <img width="773" height="130" src="<?php echo $redux_demo['opt-media-adsa8']['url'] ?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="A8" />
                                  </a>
                                </div>
                                  <?php } ?>
                            </div>
                            <input id="expa5" type="hidden" value="<?php echo $redux_demo['opt-datepicker-adsa5'] ?>">
                            <input id="expa6" type="hidden" value="<?php echo $redux_demo['opt-datepicker-adsa6'] ?>">
                            <input id="expa7" type="hidden" value="<?php echo $redux_demo['opt-datepicker-adsa7'] ?>">
                            <input id="expa8" type="hidden" value="<?php echo $redux_demo['opt-datepicker-adsa8'] ?>">
                            <script>
                             if(moment($('#expa5').val()).isBefore(moment().format('MM/DD/YYYY'))) {
                              $('#a5').hide()
                             }
                             if(moment($('#expa6').val()).isBefore(moment().format('MM/DD/YYYY'))) {
                              $('#a6').hide()
                             }
                             if(moment($('#expa7').val()).isBefore(moment().format('MM/DD/YYYY'))) {
                              $('#a7').hide()
                             }
                             if(moment($('#expa8').val()).isBefore(moment().format('MM/DD/YYYY'))) {
                              $('#a8').hide()
                             }

                              console.log(moment($('#expa1').val()).isAfter(moment().format('MM/DD/YYYY')));
                              </script>