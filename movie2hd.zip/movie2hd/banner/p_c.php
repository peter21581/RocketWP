<?php global $redux_demo; $date_now = date('Y-m-d'); ?>
<div class="textwidget custom-html-widget">
        <style type="text/css">
    #ads_fix_footer {
        width: 100%;
        margin: auto;
    }


    @media (min-width: 1281px) {
        #ads_fox_bottom {
            width: 600px;
            right: 0px;
            left: 0;
            bottom: 0px;
            margin: 0 auto;
            position: fixed;
            text-align: center;
            line-height: 0;

            z-index: 1000;
        }

        #fix_footer1 img {
            width: 100%;
            background-repeat: no-repeat;
            background-size: contain;

        }

        #fix_footer2 img {
            width: 100%;
            background-repeat: no-repeat;
            background-size: contain;

        }

        #fix_footer img {
            background-repeat: no-repeat;
            background-size: contain;
            width: 26px;
            height: 26px;
            margin-left: 60px;
        }

    }


    @media (min-width: 1025px) and (max-width: 1280px) {
        #ads_fox_bottom {
            width: 600px;
            right: 0px;
            left: 0;
            bottom: 0px;
            margin: 0 auto;
            position: fixed;
            text-align: center;
            line-height: 0;

            z-index: 1000;
        }

        #fix_footer1 img {
            width: 100%;
            background-repeat: no-repeat;
            background-size: contain;
            width: 600px;
            height: 90px;
        }

        #fix_footer2 img {
            width: 100%;
            background-repeat: no-repeat;
            background-size: contain;
            width: 600px;
            height: 90px;
        }

        #fix_footer img {
            background-repeat: no-repeat;
            background-size: contain;
            width: 26px;
            height: 26px;
            margin-left: 60px;
        }

    }


    @media (min-width: 768px) and (max-width: 1024px) {
        #ads_fox_bottom {
            width: 600px;
            right: 0px;
            left: 0;
            bottom: 0px;
            margin: 0 auto;
            position: fixed;
            text-align: center;
            line-height: 0;

            z-index: 1000;
        }

        #fix_footer1 img {
            width: 100%;
            background-repeat: no-repeat;
            background-size: contain;

        }

        #fix_footer2 img {
            width: 100%;
            background-repeat: no-repeat;
            background-size: contain;

        }

        #fix_footer img {
            background-repeat: no-repeat;
            background-size: contain;
            width: 26px;
            height: 26px;
            margin-left: 60px;
        }

    }

    @media (min-width: 768px) and (max-width: 1024px) and (orientation: landscape) {
        #ads_fox_bottom {
            width: 600px;
            right: 0px;
            left: 0;
            bottom: 0px;
            margin: 0 auto;
            position: fixed;
            text-align: center;
            line-height: 0;

            z-index: 1000;
        }

        #fix_footer1 img {
            width: 100%;
            background-repeat: no-repeat;
            background-size: contain;

        }

        #fix_footer2 img {
            width: 100%;
            background-repeat: no-repeat;
            background-size: contain;

        }

        #fix_footer img {
            background-repeat: no-repeat;
            background-size: contain;
            width: 26px;
            height: 26px;
            margin-left: 60px;
        }

    }


    @media (min-width: 481px) and (max-width: 767px) {
        #ads_fox_bottom {
            width: 300px;
            right: 0px;
            left: 0;
            bottom: 0px;
            margin: 0 auto;
            position: fixed;
            text-align: center;
            line-height: 0;

            z-index: 1000;
        }

        #fix_footer1 img {
            width: 100%;
            background-repeat: no-repeat;
            background-size: contain;

        }

        #fix_footer2 img {
            width: 100%;
            background-repeat: no-repeat;
            background-size: contain;

        }

        #fix_footer img {
            z-index: 10000;
            background-repeat: no-repeat;
            background-size: contain;
            width: 20px;
            height: 20px;
            margin-left: 300px;

        }

    }



    @media (min-width: 320px) and (max-width: 480px) {
        #ads_fox_bottom {
            width: 300px;
            right: 0px;
            left: 0;
            bottom: 0px;
            margin: 0 auto;
            position: fixed;
            text-align: center;
            line-height: 0;

            z-index: 1000;
        }

        #fix_footer1 img {
            width: 100%;
            background-repeat: no-repeat;
            background-size: contain;

        }

        #fix_footer2 img {
            width: 100%;
            background-repeat: no-repeat;
            background-size: contain;

        }

        #fix_footer img {
            background-repeat: no-repeat;
            background-size: contain;
            width: 20px;
            
            height: 20px;
            margin-left: 300px;

        }

    }
</style>
<?php if(date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsc1'])) >= $date_now) { ?>
<div id="c1" style="position: fixed; text-align: center; bottom: 0; left: 0; z-index: 9999999;">
    <div style="display: inline-block; position: relative;">
        <a href="javascript: document.getElementById('c1').remove()" style="cursor: pointer; position: absolute; top: 0; right: -28px;">
            <img src="//i0.wp.com/i.ibb.co/cJCxvDZ/ezgif-6-c27bf6b23a95-1.png" width="25" height="25">
        </a>
        <a href="<?php echo $redux_demo['opt-media-adsc1-link'] ?>" target="_blank"  >
            <img src="<?php echo $redux_demo['opt-media-adsc1']['url'] ?>">
        </a>
    </div>
</div>
<?php } ?>
<?php if(date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsc2'])) >= $date_now) { ?>
<div id="c2" style="position: fixed; text-align: center; bottom: 0; right: 0; z-index: 9999999;">
    <div style="display: inline-block; position: relative;">
        <a href="javascript: document.getElementById('c2').remove()" style="cursor: pointer; position: absolute; top: 0; left: -28px;">
            <img src="//i0.wp.com/i.ibb.co/cJCxvDZ/ezgif-6-c27bf6b23a95-1.png" width="25" height="25">
        </a>
        <a href="<?php echo $redux_demo['opt-media-adsc2-link'] ?>" target="_blank"  >
            <img src="<?php echo $redux_demo['opt-media-adsc2']['url'] ?>">
        </a>
    </div>
</div>
<?php } ?>
<div id="ads_fox_bottom">
<div id="ads_fix_footer">
    <?php if(date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsc3'])) >= $date_now) { ?>
        <div style="text-align:center;">
            <div id="fix_footer" class="closed" style="width: 26px; height: 0px; display: -webkit-inline-box; margin: 0px 0px 0px 510px; cursor: pointer;">
                <a href="javascript: document.getElementById('fix_footer2').remove();document.getElementById('fix_footer1').remove()">
                    <img src="//i0.wp.com/i.ibb.co/cJCxvDZ/ezgif-6-c27bf6b23a95-1.png" alt="close advertisement" style="padding: -2px;    margin-bottom: -22px;">
                </a>
            </div>
        </div>
 
        <div id="fix_footer2" style="display:block;float:left;margin: 0px 0 5px 0;overflow:hidden;line-height:0px;">
            <div style="display:inline-block;text-align:center;">
                <a href="<?php echo $redux_demo['opt-media-adsc3-link'] ?>" title="" target="_blank"  >
                    <img id="c3" src="<?php echo $redux_demo['opt-media-adsc3']['url'] ?>" height="100%" width="250">
                </a>
            </div>
        </div>
    <?php } ?> 
<div class="clear"></div>
<?php if(date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsc4'])) >= $date_now) { ?>
    <div id="fix_footer1" style="/* width:1000px; */display:block;float:left;/* margin: -7px 0 10px 0; */overflow:hidden;line-height:0px;">
        <div style="display:inline-block; text-align:center;">
            <a href="<?php echo $redux_demo['opt-media-adsc4-link'] ?>" title="" target="_blank"  >
                <img id="c4" src="<?php echo $redux_demo['opt-media-adsc4']['url'] ?>">
            </a>
        </div>
    </div>
    <?php } ?> 
<div class="clear"></div>
</div>
</div>
<script type="text/javascript">
    function hide() {
        document.getElementById("ads_fix_footer").style.display = "none";
    }
</script>
      </div>