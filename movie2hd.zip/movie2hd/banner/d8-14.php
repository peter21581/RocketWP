<?php global $redux_demo; ?>
                        <div class="adbr">
                             <?php if($redux_demo['opt-media-adsd8']['url']) { ?>
                            <li id="media_image-45" class="widget widget_media_image">
                                <div class="widgettitle-banner">D8</div>
                                <?php if($redux_demo['opt-rel-adsd8'] == 1) { ?>
                                    <a id="d8" href="<?php echo $redux_demo['opt-media-adsd8-link'] ?>"  rel="dofollow" target="_blank">
                                <?php } else { ?>
                                    <a id="d8" href="<?php echo $redux_demo['opt-media-adsd8-link'] ?>"  rel="nofollow" target="_blank">
                                <?php } ?>
                                <img width="200" height="580" src="<?php echo $redux_demo['opt-media-adsd8']['url'] ?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="D8" />
                              </a>
                            </li>
                              <?php } ?>
                             <?php if($redux_demo['opt-media-adsd9']['url']) { ?>
                            <li id="media_image-73" class="widget widget_media_image">
                                <div class="widgettitle-banner">D9</div>
                                <?php if($redux_demo['opt-rel-adsd9'] == 1) { ?>
                                    <a id="d9" href="<?php echo $redux_demo['opt-media-adsd9-link'] ?>"  rel="dofollow" target="_blank">
                                <?php } else { ?>
                                    <a id="d9" href="<?php echo $redux_demo['opt-media-adsd9-link'] ?>"  rel="nofollow" target="_blank">
                                <?php } ?>
                                <img width="200" height="290" src="<?php echo $redux_demo['opt-media-adsd9']['url'] ?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="D9" />
                              </a>
                            </li>
                              <?php } ?>
                             <?php if($redux_demo['opt-media-adsd10']['url']) { ?>
                            <li id="media_image-61" class="widget widget_media_image">
                                <div class="widgettitle-banner">D10</div>
                                <?php if($redux_demo['opt-rel-adsd10'] == 1) { ?>
                                    <a id="d10" href="<?php echo $redux_demo['opt-media-adsd10-link'] ?>"  rel="dofollow" target="_blank">
                                <?php } else { ?>
                                    <a id="d10" href="<?php echo $redux_demo['opt-media-adsd10-link'] ?>"  rel="nofollow" target="_blank">
                                <?php } ?>
                                <img width="200" height="290" src="<?php echo $redux_demo['opt-media-adsd10']['url'] ?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="D10" />
                              </a>
                            </li>
                              <?php } ?>
                             <?php if($redux_demo['opt-media-adsd11']['url']) { ?>
                            <li id="media_image-64" class="widget widget_media_image">
                                <div class="widgettitle-banner">D11</div>
                                <?php if($redux_demo['opt-rel-adsd11'] == 1) { ?>
                                    <a id="d11" href="<?php echo $redux_demo['opt-media-adsd11-link'] ?>"  rel="dofollow" target="_blank">
                                <?php } else { ?>
                                    <a id="d11" href="<?php echo $redux_demo['opt-media-adsd11-link'] ?>"  rel="nofollow" target="_blank">
                                <?php } ?>
                                <img width="200" height="390" src="<?php echo $redux_demo['opt-media-adsd11']['url'] ?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="D11" />
                              </a>
                            </li>
                              <?php } ?>
                             <?php if($redux_demo['opt-media-adsd12']['url']) { ?>
                            <li id="media_image-64" class="widget widget_media_image">
                                <div class="widgettitle-banner">D12</div>
                                <?php if($redux_demo['opt-rel-adsd12'] == 1) { ?>
                                    <a id="d12" href="<?php echo $redux_demo['opt-media-adsd12-link'] ?>"  rel="dofollow" target="_blank">
                                <?php } else { ?>
                                    <a id="d12" href="<?php echo $redux_demo['opt-media-adsd12-link'] ?>"  rel="nofollow" target="_blank">
                                <?php } ?>
                                <img width="200" height="390" src="<?php echo $redux_demo['opt-media-adsd12']['url'] ?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="D12" />
                              </a>
                            </li>
                              <?php } ?>
                             <?php if($redux_demo['opt-media-adsd13']['url']) { ?>
                            <li id="media_image-64" class="widget widget_media_image">
                                <div class="widgettitle-banner">D13</div>
                                <?php if($redux_demo['opt-rel-adsd13'] == 1) { ?>
                                    <a id="d13" href="<?php echo $redux_demo['opt-media-adsd13-link'] ?>"  rel="dofollow" target="_blank">
                                <?php } else { ?>
                                    <a id="d13" href="<?php echo $redux_demo['opt-media-adsd13-link'] ?>"  rel="nofollow" target="_blank">
                                <?php } ?>
                                <img width="200" height="390" src="<?php echo $redux_demo['opt-media-adsd13']['url'] ?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="D13" />
                              </a>
                            </li>
                              <?php } ?>
                             <?php if($redux_demo['opt-media-adsd14']['url']) { ?>
                            <li id="media_image-64" class="widget widget_media_image">
                                <div class="widgettitle-banner">D14</div>
                                <?php if($redux_demo['opt-rel-adsd14'] == 1) { ?>
                                    <a id="d14" href="<?php echo $redux_demo['opt-media-adsd14-link'] ?>"  rel="dofollow" target="_blank">
                                <?php } else { ?>
                                    <a id="d14" href="<?php echo $redux_demo['opt-media-adsd14-link'] ?>"  rel="nofollow" target="_blank">
                                <?php } ?>
                                <img width="200" height="390" src="<?php echo $redux_demo['opt-media-adsd14']['url'] ?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="D14" />
                              </a>
                            </li>
                              <?php } ?>
                        </div>
                            <input id="expd8" type="hidden" value="<?php echo $redux_demo['opt-datepicker-adsd8'] ?>">
                            <input id="expd9" type="hidden" value="<?php echo $redux_demo['opt-datepicker-adsd9'] ?>">
                            <input id="expd10" type="hidden" value="<?php echo $redux_demo['opt-datepicker-adsd10'] ?>">
                            <input id="expd11" type="hidden" value="<?php echo $redux_demo['opt-datepicker-adsd11'] ?>">
                            <input id="expd12" type="hidden" value="<?php echo $redux_demo['opt-datepicker-adsd12'] ?>">
                            <input id="expd13" type="hidden" value="<?php echo $redux_demo['opt-datepicker-adsd13'] ?>">
                            <input id="expd14" type="hidden" value="<?php echo $redux_demo['opt-datepicker-adsd14'] ?>">

                            <script>
                             if(moment($('#expd8').val()).isBefore(moment().format('MM/DD/YYYY'))) {
                              $('#d8').hide()
                             }
                             if(moment($('#expd9').val()).isBefore(moment().format('MM/DD/YYYY'))) {
                              $('#d9').hide()
                             }
                             if(moment($('#expd10').val()).isBefore(moment().format('MM/DD/YYYY'))) {
                              $('#d10').hide()
                             }
                             if(moment($('#expd11').val()).isBefore(moment().format('MM/DD/YYYY'))) {
                              $('#d11').hide()
                             }
                             if(moment($('#expd12').val()).isBefore(moment().format('MM/DD/YYYY'))) {
                              $('#d12').hide()
                             }
                             if(moment($('#expd13').val()).isBefore(moment().format('MM/DD/YYYY'))) {
                              $('#d13').hide()
                             }
                             if(moment($('#expd14').val()).isBefore(moment().format('MM/DD/YYYY'))) {
                              $('#d14').hide()
                             }
                            
                              console.log(moment($('#expa1').val()).isAfter(moment().format('MM/DD/YYYY')));
                              </script>