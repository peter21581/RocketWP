<?php global $redux_demo; ?>
<?php
$date_now = date('Y-m-d');
?>
<div class="row">
<div class="blog column column_1_left_right">
<?php if($redux_demo['opt-rel-adsb1'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsb1'])) >= $date_now) { ?>
    <a href="<?php echo $redux_demo['opt-media-adsb1-link'] ?>" target="_blank">
        <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsb1']['url'] ?>" width="100%">
    </a>
    
<?php } ?>
<div class="clear" style="clear: both;padding-bottom: 5px;"></div>
<?php if($redux_demo['opt-rel-adsb2'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsb2'])) >= $date_now) { ?>
    <a href="<?php echo $redux_demo['opt-media-adsb2-link'] ?>" target="_blank">
        <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsb2']['url'] ?>" width="100%" >
    </a>
<?php } ?>
<div class="clear" style="clear: both;padding-bottom: 5px;"></div>
<?php if($redux_demo['opt-rel-adsb3'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsb3'])) >= $date_now) { ?>
    <a href="<?php echo $redux_demo['opt-media-adsb3-link'] ?>" target="_blank">
        <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsb3']['url'] ?>" width="100%" >
    </a>
<?php } ?>
</div>

<div class="blog column column_1_center">
<?php if($redux_demo['opt-rel-adsa1'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsa1'])) >= $date_now) { ?>
    <a href="<?php echo $redux_demo['opt-media-adsa1-link'] ?>" target="_blank">
        <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsa1']['url'] ?>" width="100%"  style=" height: 180px; ">
    </a>
    <?php } ?>
<div class="clear" style="clear: both;padding-bottom: 5px;"></div>
<?php if($redux_demo['opt-rel-adsa2'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsa2'])) >= $date_now) { ?>
    <a href="<?php echo $redux_demo['opt-media-adsa2-link'] ?>" target="_blank">
        <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsa2']['url'] ?>" width="100%"  style=" height: 180px; ">
    </a>
    <?php } ?>
<div class="clear" style="clear: both;padding-bottom: 5px;"></div>
<?php if($redux_demo['opt-rel-adsa3'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsa3'])) >= $date_now) { ?>
    <a href="<?php echo $redux_demo['opt-media-adsa3-link'] ?>" target="_blank"  >
        <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsa3']['url'] ?>" width="100%"  style=" height: 180px; ">
    </a>
    <?php } ?>
<div class="clear" style="clear: both;padding-bottom: 5px;"></div>
<?php if($redux_demo['opt-rel-adsa4'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsa4'])) >= $date_now) { ?>
    <a href="<?php echo $redux_demo['opt-media-adsa4-link'] ?>" target="_blank"  >
        <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsa4']['url'] ?>" width="100%"  style=" height: 180px; ">
    </a>
    <?php } ?>
<div class="clear" style="clear: both;padding-bottom: 5px;"></div>
<?php if($redux_demo['opt-rel-adsa5'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsa5'])) >= $date_now) { ?>
    <a href="<?php echo $redux_demo['opt-media-adsa5-link'] ?>" target="_blank"  >
        <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsa5']['url'] ?>" width="100%"  style=" height: 180px; ">
    </a>
    <?php } ?>
<div class="clear" style="clear: both;padding-bottom: 5px;"></div>
<?php if($redux_demo['opt-rel-adsa6'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsa6'])) >= $date_now) { ?>
    <a href="<?php echo $redux_demo['opt-media-adsa6-link'] ?>" target="_blank">
        <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsa6']['url'] ?>" width="100%"  style=" height: 180px; ">
    </a>
    <?php } ?>
 
 
</div>
<div class="blog column column_1_left_right">
<?php if($redux_demo['opt-rel-adsb4'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsb4'])) >= $date_now) { ?>
    <a href="<?php echo $redux_demo['opt-media-adsb4-link'] ?>" target="_blank">
        <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsb4']['url'] ?>" width="100%">
    </a>
        <?php } ?>
<div class="clear" style="clear: both;padding-bottom: 5px;"></div>
<?php if($redux_demo['opt-rel-adsb5'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsb5'])) >= $date_now) { ?>
    <a href="<?php echo $redux_demo['opt-media-adsb5-link'] ?>" target="_blank">
        <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsb5']['url'] ?>" width="100%" >
    </a>
        <?php } ?>
<div class="clear" style="clear: both;padding-bottom: 5px;"></div>
<?php if($redux_demo['opt-rel-adsb6'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsb6'])) >= $date_now) { ?>
    <a href="<?php echo $redux_demo['opt-media-adsb6-link'] ?>" target="_blank">
        <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsb6']['url'] ?>" width="100%" >
    </a>
        <?php } ?>
</div>
</div>