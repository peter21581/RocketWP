<?php global $redux_demo;?>
<?php
$date_now = date('Y-m-d');
?>
<?php if($redux_demo['opt-rel-adsd1'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsd1'])) >= $date_now) { ?>
    <div class="adhl">
          <a id="d1" href="<?php echo $redux_demo['opt-media-adsd1-link']?>"  rel="dofollow" target="_blank">
          <img width="200" height="290" src="<?php echo $redux_demo['opt-media-adsd1']['url']?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="D1" />
        </a>
    </div>
<?php }?>
<?php if($redux_demo['opt-rel-adsd2'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsd2'])) >= $date_now) { ?>
    <div class="adhl">
          <a id="d2" href="<?php echo $redux_demo['opt-media-adsd2-link']?>"  rel="dofollow" target="_blank">
          <img width="200" height="580" src="<?php echo $redux_demo['opt-media-adsd2']['url']?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="D2" />
        </a>
    </div>
<?php }?>
  <?php if($redux_demo['opt-rel-adsd3'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsd3'])) >= $date_now) { ?>
    <div class="adhl">
          <a id="d3" href="<?php echo $redux_demo['opt-media-adsd3-link']?>"  rel="dofollow" target="_blank">
          <img width="200" height="290" src="<?php echo $redux_demo['opt-media-adsd3']['url']?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="D3" />
        </a>
    </div>
<?php }?>

  <?php if($redux_demo['opt-rel-adsd4'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsd4'])) >= $date_now) { ?>
    <div class="adhl">
          <a id="d4" href="<?php echo $redux_demo['opt-media-adsd4-link']?>"  rel="dofollow" target="_blank">
          <img width="200" height="290" src="<?php echo $redux_demo['opt-media-adsd4']['url']?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="D4" />
        </a>
    </div>
  <?php }?>
    <?php if($redux_demo['opt-rel-adsd5'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsd5'])) >= $date_now) { ?>
    <div class="adhl">
          <a id="d5" href="<?php echo $redux_demo['opt-media-adsd5-link']?>"  rel="dofollow" target="_blank">
          <img width="200" height="390" src="<?php echo $redux_demo['opt-media-adsd5']['url']?>" class="attachment-full size-full" alt="" style="max-width: 100%; height: auto;" title="D5" />
        </a>
    </div>
    <?php }?>
