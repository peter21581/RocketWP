<?php global $redux_demo;?>
<?php
$date_now = date('Y-m-d');
?>
<div class="row page_margin_top">
  <div class="blog column" style=" width: 100%; ">
    <?php if (date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsa10'])) >= $date_now) {?>
        <a href="<?php echo $redux_demo['opt-media-adsa10-link']?>" target="_blank" >
          <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsa10']['url']?>" width="100%" alt="" title="" style=" height: 180px; ">
        </a>
    <?php }?>
    <div class="clear" style="clear: both;padding-bottom: 5px;"></div>
    <?php if (date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsa11'])) >= $date_now) {?>
        <a href="<?php echo $redux_demo['opt-media-adsa11-link']?>" target="_blank">
          <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsa11']['url']?>" width="100%" alt="" title="" style=" height: 180px; ">
        </a>
    <?php }?>
    <div class="clear" style="clear: both;padding-bottom: 5px;"></div>
    <?php if (date('Y-m-d',strtotime($redux_demo['opt-datepicker-adsa12'])) >= $date_now) {?>
        <a href="<?php echo $redux_demo['opt-media-adsa12-link']?>" target="_blank" >
          <img class="ads-center " src="<?php echo $redux_demo['opt-media-adsa12']['url']?>" width="100%" alt="" title="" style=" height: 180px; ">
        </a>
    <?php }?>
  </div>
</div>