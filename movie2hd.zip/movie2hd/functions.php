<?php
add_action( 'after_setup_theme', 'register_custom_nav_menus1' );
function register_custom_nav_menus1() {
	register_nav_menus( array(
        'main_menu' => 'เมนูหลัก',
    
	) );
}
    	
add_theme_support( 'post-thumbnails' );
function my_pagination_rewrite() {
    add_rewrite_rule('blog/page/?([0-9]{1,})/?$', 'index.php?category_name=blog&paged=$matches[1]', 'top');
}
add_action('init', 'my_pagination_rewrite');

function wpb_widgets_init() {
 
    register_sidebar( array(
        'name'          => 'Custom Header Widget Area',
        'id'            => 'custom-header-widget',
        'before_widget' => '<div class="chw-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="chw-title">',
        'after_title'   => '</h2>',
    ) );
 
}
add_action( 'widgets_init', 'wpb_widgets_init' );
?>