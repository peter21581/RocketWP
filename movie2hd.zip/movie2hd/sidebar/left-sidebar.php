<div class="blog column column_1_left_year">
  <?php global $redux_demo;
  $date_now = date('m/d/Y');?>
  <div id="wp_categories_widget-3" class="Wdgt widget_wp_categories_widget">
    <div class="Title">ประเภท</div>
    <div class="ve-cat-widget-div">
      <ul class="ve-cat-widget-listing">
        <li><a href="<?php echo get_category_link(10);?>" >หนัง Netflix</a></li>
        <li><a href="<?php echo get_category_link(32);?>" >หนังจีน</a></li>
        <li><a href="<?php echo get_category_link(33);?>" >หนังซอมบี้</a></li>
        <li><a href="<?php echo get_category_link(34);?>" >หนังญี่ปุ่น</a></li>
        <li><a href="<?php echo get_category_link(7);?>" >หนังฝรั่ง</a></li>
        <li><a href="<?php echo get_category_link(35);?>" >หนังอินเดีย</a></li>
        <li><a href="<?php echo get_category_link(36);?>" >หนังเกาหลี</a></li>
        <li><a href="<?php echo site_url();?>" >หนังใหม่</a></li>
        <li><a href="<?php echo get_category_link(37);?>" >หนังไทย</a></li>
      </ul>
    </div>
  </div>
  <div id="custom_html-5" class="widget_text Wdgt widget_custom_html">
    <div class="textwidget custom-html-widget">
      <ul class="ve-cat-widget-listing">
        <li><a href="<?php echo site_url()?>/fillter-year?y=2020" >หนังใหม่ 2020</a></li>
        <li><a href="<?php echo site_url()?>/fillter-year?y=2019" >หนังใหม่ 2019</a></li>
        <li><a href="<?php echo site_url()?>/fillter-year?y=2018" >หนังใหม่ 2018</a></li>
      </ul>
    </div>
  </div>
  <?php
  if (is_single() && 'post' == get_post_type()) {
      $template = locate_template('banner/p_d.php');
  }
  else {
      $template = locate_template('banner/d.php');
  }

  if ($template) {
      load_template($template);
  }
  ?>


</div>
