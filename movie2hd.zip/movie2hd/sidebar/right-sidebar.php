<div class="blog column column_1_right_year">
  <?php global $redux_demo;
  $date_now = date('Y-m-d');?>
  <div id="wp_categories_widget-4" class="Wdgt widget_wp_categories_widget">
    <div class="Title">หมวดหมู่</div>
    <div class="ve-cat-widget-div">
      <ul class="ve-cat-widget-listing">
        <li><a href="<?php echo get_category_link(12);?>" >Action บู้ (<?php echo get_category(12)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(13);?>" >Adventure ผจญภัย (<?php echo get_category(13)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(16);?>" >Biography ชีวประวัติ (<?php echo get_category(16)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(15);?>" >Cartoon การ์ตูน (<?php echo get_category(15)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(14);?>" >Comedy ตลก (<?php echo get_category(14)->category_count;?>)</a></li>
      </ul>
    </div>
  </div>
  <?php if ( is_single() && 'post' == get_post_type() ) { ?>
<?php if ($redux_demo['opt-rel-adse1'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adse1'])) >= $date_now) {?>
      <div id="e1" class="widget_text Wdgt widget_custom_html">
        <div class="textwidget custom-html-widget">
          <a href="<?php echo $redux_demo['opt-media-adse1-link']?>" target="_blank">
            <img class="ads-center " src="<?php echo $redux_demo['opt-media-adse1']['url']?>" width="100%" height="100%">
          </a>
        </div>
      </div>
  <?php }?>
<?php if ($redux_demo['opt-rel-adse2'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adse2'])) >= $date_now) {?>
      <div id="e2" class="widget_text Wdgt widget_custom_html">
        <div class="textwidget custom-html-widget">
          <div class="clear" style="clear: both;padding-bottom: 5px;"></div>
          <a href="<?php echo $redux_demo['opt-media-adse2-link']?>" target="_blank">
            <img class="ads-center " src="<?php echo $redux_demo['opt-media-adse2']['url']?>" width="100%" height="100%">
          </a>
        </div>
      </div>
  <?php }?>

<?php }else{ ?>
  <?php if (date('Y-m-d',strtotime($redux_demo['opt-datepicker-adse1'])) >= $date_now) {?>
      <div id="e1" class="widget_text Wdgt widget_custom_html">
        <div class="textwidget custom-html-widget">
          <a href="<?php echo $redux_demo['opt-media-adse1-link']?>" target="_blank">
            <img class="ads-center " src="<?php echo $redux_demo['opt-media-adse1']['url']?>" width="100%" height="100%">
          </a>
        </div>
      </div>
  <?php }?>
<?php if (date('Y-m-d',strtotime($redux_demo['opt-datepicker-adse2'])) >= $date_now) {?>
      <div id="e2" class="widget_text Wdgt widget_custom_html">
        <div class="textwidget custom-html-widget">
          <div class="clear" style="clear: both;padding-bottom: 5px;"></div>
          <a href="<?php echo $redux_demo['opt-media-adse2-link']?>" target="_blank">
            <img class="ads-center " src="<?php echo $redux_demo['opt-media-adse2']['url']?>" width="100%" height="100%">
          </a>
        </div>
      </div>
  <?php }?>
<?php } ?>
  <div id="wp_categories_widget-5" class="Wdgt widget_wp_categories_widget">
    <div class="ve-cat-widget-div">
      <ul class="ve-cat-widget-listing">
        <li><a href="<?php echo get_category_link(17);?>" >Crime อาชญากรรม (<?php echo get_category(17)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(18);?>" >Documentary สารคดี (<?php echo get_category(18)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(19);?>" >Drama ชีวิต (<?php echo get_category(19)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(20);?>" >Family ครอบครัว (<?php echo get_category(20)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(21);?>" >Fantasy เทพนิยาย (<?php echo get_category(21)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(38);?>" >History ประวัติศาสตร์ (<?php echo get_category(38)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(22);?>" >Horror สยองขวัญ (<?php echo get_category(22)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(23);?>" >Music เพลง (<?php echo get_category(23)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(24);?>" >Mystery ลึกลับซ่อนเงื่อน (<?php echo get_category(24)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(25);?>" >Romance โรแมนติก (<?php echo get_category(25)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(26);?>" >Sci-Fi วิทยาศาสตร์ (<?php echo get_category(26)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(27);?>" >Sport กีฬา (<?php echo get_category(27)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(28);?>" >Thriller ระทึกขวัญ (<?php echo get_category(28)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(29);?>" >War สงคราม (<?php echo get_category(29)->category_count;?>)</a></li>
        <li><a href="<?php echo get_category_link(30);?>" >Western คาวบอยตะวันตก (<?php echo get_category(30)->category_count;?>)</a></li>
      </ul>
    </div>
  </div>

  <div id="wp_categories_widget-2" class="Wdgt widget_wp_categories_widget">
    <div class="Title">รวมหนังภาคต่อ</div>
    <div id="header-widget-area" class="chw-widget-area widget-area" role="complementary">
<?php dynamic_sidebar('custom-header-widget');?>
    </div>
  </div>

<?php if ( is_single() && 'post' == get_post_type() ) { ?>
<?php if ($redux_demo['opt-rel-adse3'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adse3'])) >= $date_now) {?>
      <div id="e1" class="widget_text Wdgt widget_custom_html">
        <div class="textwidget custom-html-widget">
          <a href="<?php echo $redux_demo['opt-media-adse3-link']?>" target="_blank">
            <img class="ads-center " src="<?php echo $redux_demo['opt-media-adse3']['url']?>" width="100%" height="100%">
          </a>
        </div>
      </div>
  <?php }?>
<?php if ($redux_demo['opt-rel-adse4'] == 1 and date('Y-m-d',strtotime($redux_demo['opt-datepicker-adse4'])) >= $date_now) {?>
      <div id="e2" class="widget_text Wdgt widget_custom_html">
        <div class="textwidget custom-html-widget">
          <div class="clear" style="clear: both;padding-bottom: 5px;"></div>
          <a href="<?php echo $redux_demo['opt-media-adse4-link']?>" target="_blank">
            <img class="ads-center " src="<?php echo $redux_demo['opt-media-adse4']['url']?>" width="100%" height="100%">
          </a>
        </div>
      </div>
  <?php }?>

<?php }else{ ?>
  <?php if (date('Y-m-d',strtotime($redux_demo['opt-datepicker-adse3'])) >= $date_now) {?>
      <div id="e1" class="widget_text Wdgt widget_custom_html">
        <div class="textwidget custom-html-widget">
          <a href="<?php echo $redux_demo['opt-media-adse3-link']?>" target="_blank">
            <img class="ads-center " src="<?php echo $redux_demo['opt-media-adse3']['url']?>" width="100%" height="100%">
          </a>
        </div>
      </div>
  <?php }?>
<?php if (date('Y-m-d',strtotime($redux_demo['opt-datepicker-adse4'])) >= $date_now) {?>
      <div id="e2" class="widget_text Wdgt widget_custom_html">
        <div class="textwidget custom-html-widget">
          <div class="clear" style="clear: both;padding-bottom: 5px;"></div>
          <a href="<?php echo $redux_demo['opt-media-adse4-link']?>" target="_blank">
            <img class="ads-center " src="<?php echo $redux_demo['opt-media-adse4']['url']?>" width="100%" height="100%">
          </a>
        </div>
      </div>
  <?php }?>
<?php } ?>
</div>
