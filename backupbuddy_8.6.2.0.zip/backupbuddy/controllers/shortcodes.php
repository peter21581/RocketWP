<?php
/**
 * Shortcodes Controller
 *
 * @package BackupBuddy
 */

/**
 * Main Class for Shortcodes
 */
class pb_backupbuddy_shortcodes extends pluginbuddy_shortcodescore {

}
