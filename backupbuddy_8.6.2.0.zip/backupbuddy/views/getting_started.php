<?php
/**
 * Getting Started View
 *
 * @package BackupBuddy
 */

backupbuddy_core::versions_confirm();

pb_backupbuddy::load_script( 'jquery' );
