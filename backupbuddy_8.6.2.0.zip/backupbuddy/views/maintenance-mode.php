<?php
/**
 * Maintenance Mode while site is restored.
 *
 * @package BackupBuddy
 */

?>
<!DOCTYPE html>
<html>
<head>
	<title>BackupBuddy Maintenance Mode</title>
	<style type="text/css" media="screen">
		body {
			text-align: center;
		}
	</style>
</head>
<body>
	<h1>Under Maintenance</h1>

	<p>Website under planned maintenance. Please check back later.</p>
</body>
</html>
