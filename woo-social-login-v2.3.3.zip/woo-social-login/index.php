<?php
/* Silence is golden */