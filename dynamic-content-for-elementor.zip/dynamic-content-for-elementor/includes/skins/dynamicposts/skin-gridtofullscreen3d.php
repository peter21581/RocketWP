<?php
namespace DynamicContentForElementor\Includes\Skins;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;

use DynamicContentForElementor\DCE_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Skin_Gridtofullscreen3d extends Skin_Grid {

	protected function _register_controls_actions() {
		parent::_register_controls_actions();

		add_action( 'elementor/element/dce-dynamicposts-v2/section_dynamicposts/after_section_end', [ $this, 'register_additional_gridtofullscreen3d_controls' ] );

	}

	public function get_script_depends() {
		return [];
    }
	public function get_style_depends() {
		return [];
    }
	public function get_id() {
		return 'gridtofullscreen3d';
	}

	public function get_title() {
		return __( 'Grid to Fullscreen 3D', 'dynamic-content-for-elementor' );
	}

	public function register_additional_gridtofullscreen3d_controls() {

		$this->start_controls_section(
            'section_gridtofullscreen3d', [
	            'label' => '<i class="dynicon eicon-parallax"></i> '.__('Grid to Fullscreen 3D', 'dynamic-content-for-elementor'),
	            'tab' => Controls_Manager::TAB_CONTENT,

            ]
        );
		// Effects
		// 6 Presettings
		$this->add_control(
            'gridtofullscreen3d_effects', [
	            'label' => __('Grid-to-Fullscreen Effect', 'dynamic-content-for-elementor'),
	            'type' => Controls_Manager::SELECT,
	            'default' => 'effect1',

	            'options' => [
	            	'effect1' => 'Effect 1',
	            	'effect2' => 'Effect 2',
	            	'effect3' => 'Effect 3',
	            	'effect4' => 'Effect 4',
	            	'effect5' => 'Effect 5',
	            	'effect6' => 'Effect 6',
	            	'custom_effect' => 'Custom Effect',
	            ],
	            'frontend_available' => true,
	            'render_type' => 'template'
            ]
        );
		// Custom
		// Duration:
		$this->add_responsive_control(
            'gridtofullscreen3d_duration', [
                'label' => __('Duration', 'dynamic-content-for-elementor'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 1.8,
                ],
                'range' => [
                    'px' => [
                        'max' => 5,
                        'min' => 0.3,
                        'step' => 0.1,
                    ],
                ],
                'frontend_available' => true,
            ]
        );
		// Activations:
		//		- corners
		//		- topLeft
		//		- sides
		//		- top
		//		- left
		//		- bottom
		//		- bottomStep
		//		- sinX
		//		- center
		//		- mouse
		//		- closestCorner
		//		- closestSide
		$this->add_control(
            'gridtofullscreen3d_activations', [
	            'label' => __('Activations', 'dynamic-content-for-elementor'),
	            'type' => Controls_Manager::SELECT,
	            'default' => 'corners',

	            'options' => [
	            	'corners' 		=> 'Corners',
	            	'topLeft' 		=> 'TopLeft',
	            	'sides' 		=> 'Sides',
	            	'top' 			=> 'Top',
	            	'left' 			=> 'Left',
	            	'bottom' 		=> 'Bottom',
	            	'center' 		=> 'center',
	            	'bottomStep' 	=> 'BottomStep',
	            	'sinX' 			=> 'SinX',
	            	'mouse' 		=> 'Mouse',
	            	'closestCorner' => 'ClosestCorner',
	            	'closestSide' 	=> 'ClosestSide',
	            ],
	            'frontend_available' => true,
	            'render_type' => 'template',
	            'condition' => [
	             	$this->get_control_id('gridtofullscreen3d_effects') => 'custom_effect',
	            ]
            ]
        );


		// ...transformation
		//		- flipX
		//		- simplex
		//			Props:
		//				seed: 0;
    	//				amplitudeX: 0.5
    	//				amplitudeY: 0.5
    	//				frequencyX: 1
    	//				frequencyY: 0.75
    	//				progressLimit: 0.5
		//		- wavy
		// 			Props:
		// 				seed: "8000",
        // 				frequency: 0.1,
        // 				amplitude: 1
		//		- circle
		$this->add_control(
            'gridtofullscreen3d_transformation', [
	            'label' => __('Transformation', 'dynamic-content-for-elementor'),
	            'type' => Controls_Manager::SELECT,
	            'default' => 'none',

	            'options' => [
	            	'none'			=> 'None',
	            	'flipX' 		=> 'FlipX',
	            	'simplex' 		=> 'Simplex',
	            	'wavy' 			=> 'Wavy',
	            	'circle' 		=> 'Circle',
	            ],
	            'frontend_available' => true,
	            'render_type' => 'template',
	            'condition' => [
	             	$this->get_control_id('gridtofullscreen3d_effects') => 'custom_effect',
	            ]
            ]
        );

		$this->add_control(
            'gridtofullscreen3d_easing_heading', [
                'label' => __('Timing equation Easing', 'dynamic-content-for-elementor'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
	             	$this->get_control_id('gridtofullscreen3d_effects') => 'custom_effect',
	            ]
            ]
        );
		// ----------------------------------
		// toFullscreen Easing
		$this->add_control(
            'gridtofullscreen3d_easing_to_fullscreen_popover', [
                'label' => __('To Fullscreen', 'dynamic-content-for-elementor'),
                'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                'label_off' => __('Default', 'dynamic-content-for-elementor'),
                'label_on' => __('Custom', 'dynamic-content-for-elementor'),
                'return_value' => 'yes',
                'condition' => [
	             	$this->get_control_id('gridtofullscreen3d_effects') => 'custom_effect',
	            ]
            ]
        );
        $this->parent->start_popover();
		$this->add_control(
            'gridtofullscreen3d_easing_morph_to_fullscreen', [
                'label' => __('To fullscreen', 'dynamic-content-for-elementor'),
                'type' => Controls_Manager::SELECT,
                'options' => ['' => __('Default', 'dynamic-content-for-elementor')] + DCE_Helper::get_gsap_ease(),
                'default' => '',
                'frontend_available' => true,
                'label_block' => false,
                'condition' => [
	             	$this->get_control_id('gridtofullscreen3d_effects') => 'custom_effect',
	             	$this->get_control_id('gridtofullscreen3d_easing_to_fullscreen_popover') => 'yes',
	            ]
            ]
        );
        $this->add_control(
            'gridtofullscreen3d_easing_morph_ease_to_fullscreen', [
                'label' => __('Equation to fullscreen', 'dynamic-content-for-elementor'),
                'type' => Controls_Manager::SELECT,
                'options' => ['' => __('Default', 'dynamic-content-for-elementor')] + DCE_Helper::get_gsap_timingFunctions(),
                'default' => '',
                'frontend_available' => true,
                'label_block' => false,
                'condition' => [
	             	$this->get_control_id('gridtofullscreen3d_effects') => 'custom_effect',
	             	$this->get_control_id('gridtofullscreen3d_easing_to_fullscreen_popover') => 'yes',
	            ]
            ]
        );
        $this->parent->end_popover();

        // ----------------------------------
		// toGrid Easing
		$this->add_control(
            'gridtofullscreen3d_easing_to_grid_popover', [
                'label' => __('Timing function to Grid', 'dynamic-content-for-elementor'),
                'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                'label_off' => __('Default', 'dynamic-content-for-elementor'),
                'label_on' => __('Custom', 'dynamic-content-for-elementor'),
                'return_value' => 'yes',
                'condition' => [
	             	$this->get_control_id('gridtofullscreen3d_effects') => 'custom_effect',
	            ]
            ]
        );
        $this->parent->start_popover();
		$this->add_control(
            'gridtofullscreen3d_easing_morph_to_grid', [
                'label' => __('Easing to fullscreen', 'dynamic-content-for-elementor'),
                'type' => Controls_Manager::SELECT,
                'options' => ['' => __('Default', 'dynamic-content-for-elementor')] + DCE_Helper::get_gsap_ease(),
                'default' => '',
                'frontend_available' => true,
                'label_block' => false,
                'condition' => [
	             	$this->get_control_id('gridtofullscreen3d_effects') => 'custom_effect',
	             	$this->get_control_id('gridtofullscreen3d_easing_to_grid_popover') => 'yes',
	            ]
            ]
        );
        $this->add_control(
            'gridtofullscreen3d_easing_morph_ease_to_grid', [
                'label' => __('Equation to fullscreen', 'dynamic-content-for-elementor'),
                'type' => Controls_Manager::SELECT,
                'options' => ['' => __('Default', 'dynamic-content-for-elementor')] + DCE_Helper::get_gsap_timingFunctions(),
                'default' => '',
                'frontend_available' => true,
                'label_block' => false,
                'condition' => [
	             	$this->get_control_id('gridtofullscreen3d_effects') => 'custom_effect',
	             	$this->get_control_id('gridtofullscreen3d_easing_to_grid_popover') => 'yes',
	            ]
            ]
        );
        $this->parent->end_popover();

        $this->add_control(
            'gridtofullscreen3d_panel_heading', [
                'label' => __('PANEL', 'dynamic-content-for-elementor'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',

            ]
        );
        // PANNELLO
		$this->add_responsive_control(
            'gridtofullscreen3d_panel_position', [
	            'label' => __('Position', 'dynamic-content-for-elementor'),
	            'type' => Controls_Manager::CHOOSE,
	            'options' => [
	            	'left' => [
	                    'title' => __('Left', 'dynamic-content-for-elementor'),
	                    'icon' => 'eicon-h-align-left',
	                ],

	                'right' => [
	                    'title' => __('Right', 'dynamic-content-for-elementor'),
	                    'icon' => 'eicon-h-align-right',
	                ],
	                /*'top' => [
	                    'title' => __('Top', 'dynamic-content-for-elementor'),
	                    'icon' => 'eicon-v-align-top',
	                ],*/
	                /*'bottom' => [
	                    'title' => __('Bottom', 'dynamic-content-for-elementor'),
	                    'icon' => 'eicon-v-align-bottom',
	                ],*/

	            ],
	            'default' => 'right',
	            'prefix_class' => 'dce-panel-position-',
	            'frontend_available' => true,
	            'render_type' => 'template',
            ]
        );
        $this->add_control(
            'gridtofullscreen3d_template',
            [
                'label' => __('Template', 'dynamic-content-for-elementor'),
                'type' => 'ooo_query',
                'placeholder' => __('Template Name', 'dynamic-content-for-elementor'),
                'label_block' => true,
                'query_type' => 'posts',
                'object_type' => 'elementor_library',
                'frontend_available' => true,
                /*'condition' => [
	                $this->get_control_id('grid_type') => ['blog']
	            ],*/
            ]
        );

        //Bg color
		// background text color
        $this->add_control(
            'gridtofullscreen3d_panel_background', [
	            'label' => __('Background', 'dynamic-content-for-elementor'),
	            'type' => Controls_Manager::COLOR,
	            'default' => '',
	            'selectors' => [
	                '{{WRAPPER}} .dce-gridtofullscreen3d-container .fullview__item-box' => 'background-color: {{VALUE}};'
	            ],
	            'condition' => [
	             	$this->get_control_id('gridtofullscreen3d_template!') => '',
	            ]
            ]
        );
        // ----------------------------
        // TITLE
        $this->add_control(
            'gridtofullscreen3d_panel_title_heading', [
                'label' => __('Title', 'dynamic-content-for-elementor'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );
        //Title color
        $this->add_control(
            'gridtofullscreen3d_panel_title_color', [
	            'label' => __('Color', 'dynamic-content-for-elementor'),
	            'type' => Controls_Manager::COLOR,
	            'default' => '',
	            'selectors' => [
	                '{{WRAPPER}} .dce-gridtofullscreen3d-container .fullview__item-title' => 'color: {{VALUE}};'
	            ]
            ]
        );
        //Title Typography
        $this->add_group_control(
            Group_Control_Typography::get_type(), [
	            'name' => 'gridtofullscreen3d_panel_title_typography',
	            'label' => __('Typography', 'dynamic-content-for-elementor'),
	            'selector' => '{{WRAPPER}} .dce-gridtofullscreen3d-container .fullview__item-title',

            ]
        );
        //////////////////////////////////////////////////////////////////
        $this->end_controls_section();
	}
	protected function register_style_controls() {
		parent::register_style_controls();

		// $this->start_controls_section(
		// 	'section_style_gridtofullscreen3d',
		// 	[
		// 		'label' => __( 'Grid to Fullscreen 3D', 'dynamic-content-for-elementor' ),
		// 		'tab' => Controls_Manager::TAB_STYLE,
		// 	]
		// );

		// $this->end_controls_section();
	}

	protected function render_image($settings) {
		// Settings ------------------------------
		//$thumbnail_size = $settings['thumbnail_size']; //non serve così
		//$size_image = $settings['size_image']['size']; //style
		$use_bgimage = $settings['use_bgimage'];
		//$height_bgimage = $settings['height_bgimage']; //style
		$use_overlay = $settings['use_overlay'];
        $use_overlay_hover = $this->parent->get_settings('use_overlay_hover');
		//$overlay_color = $settings['overlay_color']; //style
		//$overlay_opacity = $settings['overlay_opacity']; //style
		//
    	$use_link = $settings['use_link'];

		// ---------------------------------------
		$setting_key = $settings['thumbnail_size_size'];

		$image_attr = [
			'class' => $this->get_image_class()
		];
		$image_url = Group_Control_Image_Size::get_attachment_image_src(get_post_thumbnail_id(), 'thumbnail_size', $settings);
		$thumbnail_html = wp_get_attachment_image( get_post_thumbnail_id(), $setting_key, false, $image_attr );

		if ( empty( $thumbnail_html ) ) {
			return;
		}

		$bgimage = '';
		if($use_bgimage){
			$bgimage = ' dce-post-bgimage';
		}
		$overlayimage = '';
		if($use_overlay){
			$overlayimage = ' dce-post-overlayimage';
		}
        $overlayhover = '';
        if($use_overlay_hover){
            $overlayhover = ' dce-post-overlayhover';
        }
        $html_tag = 'div';
        $attribute_link = '';
        if($use_link){
            $html_tag = 'a';
            $attribute_link = ' href="'.$this->current_permalink.'"';
        }
        echo '<'.$html_tag.' class="dce-post-image'.$bgimage.$overlayimage.$overlayhover.'"'.$attribute_link.'>';

        		echo $thumbnail_html;
                $this->render_image_large();


        echo '</'.$html_tag.'>';

	}
	protected function render_posts_before() {
		echo '<div id="app"></div>';
	}

	protected function render_posts_after() {
		$this->parent->query_posts();

		$query = $this->parent->get_query();

		if ( ! $query->found_posts ) {
			return;
		}
		echo '<div class="fullview">';

		if ( $query->in_the_loop ) {
			$this->current_permalink = get_permalink();
			$this->current_id = get_the_ID();
			//
			$this->render_fullview_item();
		} else {
			while ( $query->have_posts() ) {
				$query->the_post();

				$this->current_permalink = get_permalink();
				$this->current_id = get_the_ID();
				//
				$this->render_fullview_item();
			}
		}

		wp_reset_postdata();

		echo '<button class="fullview__close" aria-label="Close preview"><svg aria-hidden="true" width="24" height="22px" viewBox="0 0 24 22"><path d="M11 9.586L20.192.393l1.415 1.415L12.414 11l9.193 9.192-1.415 1.415L11 12.414l-9.192 9.193-1.415-1.415L9.586 11 .393 1.808 1.808.393 11 9.586z" /></svg></button>';

		echo '</div>';
	}

	public function render_fullview_item(){
		$panel_template_id = $this->get_instance_value( 'gridtofullscreen3d_template' );
		?>
		<div class="fullview__item">
				<h2 class="fullview__item-title"><?php get_the_title() ? the_title() : the_ID(); ?></h2>
				<?php if($panel_template_id){ ?>
				<div class="fullview__item-box"><?php $this->render_template($panel_template_id); ?></div>
				<?php } ?>
			</div>
		<?php
	}

	public function render_image_large(){
		$image_url = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full');
		echo '<img class="grid__item-img grid__item-img--large" src="'.$image_url[0].'" />';
	}

	// Classes ----------
	public function get_container_class() {
		return 'dce-gridtofullscreen3d-container dce-skin-' . $this->get_id() . ' dce-skin-' . parent::get_id() . ' dce-skin-' . parent::get_id().'-'.$this->get_instance_value( 'grid_type' );
	}
    public function get_wrapper_class() {
        return 'dce-gridtofullscreen3d-wrapper dce-wrapper-' . $this->get_id() . ' dce-wrapper-' . parent::get_id();
    }
    public function get_item_class() {
        return 'dce-gridtofullscreen3d-item dce-item-' . $this->get_id() . ' dce-item-' . parent::get_id();
    }
    public function get_image_class() {
        return 'grid__item-img';
    }
}
