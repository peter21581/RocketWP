<div class="addons-info-holder" data-route="<?php echo OsRouterHelper::build_route_name('addons', 'load_addons_list') ?>">
	<span class="loading"><?php _e('Loading Addons Information', 'latepoint'); ?></span>
</div>