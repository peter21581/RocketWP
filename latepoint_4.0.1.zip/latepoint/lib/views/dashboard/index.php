
<div class="os-dashboard-row">
	<div class="os-dashboard-column os-wider">
		<?php echo $widget_daily_bookings_chart; ?>
	</div>
	<div class="os-dashboard-column">
		<?php echo $widget_top_agents; ?>
	</div>
</div>
<div class="os-dashboard-row">
	<div class="os-dashboard-column">
		<?php echo $widget_upcoming_appointments; ?>
	</div>
</div>
<div class="os-dashboard-row">
	<div class="os-dashboard-column">
		<?php echo $widget_agents_bookings_timeline; ?>
	</div>
</div>
<div class="os-dashboard-row">
	<div class="os-dashboard-column">
		<?php echo $widget_agents_availability_timeline; ?>
	</div>
</div>