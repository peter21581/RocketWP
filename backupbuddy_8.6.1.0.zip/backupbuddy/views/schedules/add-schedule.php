<?php
/**
 * Add New Schedule Tab
 *
 * @package BackupBuddy
 */

?>
<h1><?php esc_html_e( 'Add New Schedule', 'it-l10n-backupbuddy' ); ?></h1>
<?php
$schedule_form->display_settings( '+ Add Schedule' );
