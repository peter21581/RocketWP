<?php
/**
 * OneDrive Auth API Credentials
 *
 * @package BackupBuddy
 */

return array(
	'ONEDRIVE_CLIENT_ID'     => 'f2827955-4a83-4f78-84e8-7db55633ce3b',
	'ONEDRIVE_CLIENT_SECRET' => '+1xeHZFgb54b2JlsIhIfBzMUyTBi]H]*',
	'ONEDRIVE_REDIRECT_URI'  => 'https://oauth-redirect.ithemes.com/onedrive/auth',
);
